package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.AppNavDestination
import com.example.ui.MainViewModel
import com.example.ui.admin.AdminScreen
import com.example.ui.components.MiniAudioPlayerBar
import com.example.ui.home.HomeScreen
import com.example.ui.onboarding.OnboardingScreen
import com.example.ui.profile.ProfileScreen
import com.example.ui.program.DayDetailScreen
import com.example.ui.program.ProgramScreen
import com.example.ui.reset.ResetScreen
import com.example.ui.theme.DeepNavy
import com.example.ui.theme.MentalSharpnessTheme
import com.example.ui.theme.MutedGold
import com.example.ui.theme.SoftSageDark
import com.example.ui.theme.WarmCard
import com.example.ui.theme.WarmTextMuted
import com.example.ui.theme.WarmWhite
import com.example.ui.track.TrackScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MentalSharpnessTheme {
                val mainViewModel: MainViewModel = viewModel()
                MentalSharpnessApp(mainViewModel)
            }
        }
    }
}

@Composable
fun MentalSharpnessApp(viewModel: MainViewModel) {
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
    val selectedDayNumber by viewModel.selectedDayNumber.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val audioState by viewModel.audioState.collectAsStateWithLifecycle()
    val completions by viewModel.allCompletions.collectAsStateWithLifecycle()
    val checkIns by viewModel.allCheckIns.collectAsStateWithLifecycle()
    val brainFogEntries by viewModel.allBrainFogEntries.collectAsStateWithLifecycle()
    val progress by viewModel.progressSummary.collectAsStateWithLifecycle()
    val adminStatus by viewModel.adminNotificationStatus.collectAsStateWithLifecycle()

    // If first-time user hasn't completed onboarding, show unhurried 6-step intro
    if (!settings.isOnboarded) {
        OnboardingScreen(
            onFinish = { goals, reminderTime ->
                viewModel.completeOnboarding(goals, reminderTime)
            }
        )
        return
    }

    // System Back Handler
    BackHandler(enabled = currentTab != AppNavDestination.HOME) {
        if (currentTab == AppNavDestination.DAY_DETAIL) {
            viewModel.navigateTo(AppNavDestination.PROGRAM)
        } else {
            viewModel.navigateTo(AppNavDestination.HOME)
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = WarmWhite,
        bottomBar = {
            Column(modifier = Modifier.background(WarmWhite)) {
                // Persistent Floating Mini Audio Bar
                MiniAudioPlayerBar(
                    audioState = audioState,
                    onResume = { viewModel.resumeAudio() },
                    onPause = { viewModel.pauseAudio() },
                    onClose = { viewModel.stopAudio() }
                )

                if (currentTab != AppNavDestination.ADMIN && currentTab != AppNavDestination.DAY_DETAIL) {
                    NavigationBar(
                        containerColor = Color.White,
                        contentColor = DeepNavy,
                        tonalElevation = 6.dp
                    ) {
                        NavigationBarItem(
                            selected = currentTab == AppNavDestination.HOME,
                            onClick = { viewModel.navigateTo(AppNavDestination.HOME) },
                            icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                            label = { Text("Home") },
                            colors = navBarItemColors(),
                            modifier = Modifier.testTag("nav_home")
                        )

                        NavigationBarItem(
                            selected = currentTab == AppNavDestination.PROGRAM,
                            onClick = { viewModel.navigateTo(AppNavDestination.PROGRAM) },
                            icon = { Icon(Icons.Default.DateRange, contentDescription = "30 Days") },
                            label = { Text("Program") },
                            colors = navBarItemColors(),
                            modifier = Modifier.testTag("nav_program")
                        )

                        NavigationBarItem(
                            selected = currentTab == AppNavDestination.TRACK,
                            onClick = { viewModel.navigateTo(AppNavDestination.TRACK) },
                            icon = { Icon(Icons.Default.Insights, contentDescription = "Track") },
                            label = { Text("Track") },
                            colors = navBarItemColors(),
                            modifier = Modifier.testTag("nav_track")
                        )

                        NavigationBarItem(
                            selected = currentTab == AppNavDestination.RESET,
                            onClick = { viewModel.navigateTo(AppNavDestination.RESET) },
                            icon = { Icon(Icons.Default.SelfImprovement, contentDescription = "Reset") },
                            label = { Text("Reset") },
                            colors = navBarItemColors(),
                            modifier = Modifier.testTag("nav_reset")
                        )

                        NavigationBarItem(
                            selected = currentTab == AppNavDestination.PROFILE,
                            onClick = { viewModel.navigateTo(AppNavDestination.PROFILE) },
                            icon = { Icon(Icons.Default.Person, contentDescription = "Profile") },
                            label = { Text("Profile") },
                            colors = navBarItemColors(),
                            modifier = Modifier.testTag("nav_profile")
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                AppNavDestination.HOME -> {
                    val todayLesson = viewModel.repository.getDayLesson(progress.currentDay)
                    HomeScreen(
                        settings = settings,
                        progress = progress,
                        todayLesson = todayLesson,
                        onStartToday = { dayNum -> viewModel.openDayDetail(dayNum) },
                        onOpenReset = { viewModel.navigateTo(AppNavDestination.RESET) },
                        onSaveCheckIn = { s, e, f, st, c ->
                            viewModel.saveQuickCheckIn(s, e, f, st, c)
                        }
                    )
                }

                AppNavDestination.PROGRAM -> {
                    ProgramScreen(
                        allLessons = viewModel.repository.allLessons,
                        completions = completions,
                        onSelectDay = { dayNum -> viewModel.openDayDetail(dayNum) }
                    )
                }

                AppNavDestination.DAY_DETAIL -> {
                    val lesson = viewModel.repository.getDayLesson(selectedDayNumber)
                    val completion = completions.firstOrNull { it.dayNumber == selectedDayNumber }
                    DayDetailScreen(
                        lesson = lesson,
                        completion = completion,
                        onCompleteDay = { dNum, ref ->
                            viewModel.completeCurrentDay(dNum, ref)
                        },
                        onPlayAudio = {
                            val session = viewModel.repository.audioSessions.firstOrNull { it.durationSec == lesson.audioDurationSec }
                                ?: viewModel.repository.audioSessions.first()
                            viewModel.playAudioSession(session)
                        },
                        onBack = { viewModel.navigateTo(AppNavDestination.PROGRAM) }
                    )
                }

                AppNavDestination.TRACK -> {
                    TrackScreen(
                        checkIns = checkIns,
                        brainFogEntries = brainFogEntries,
                        onSaveBrainFogEntry = { sleep, energy, stress, focus, clarity, act, hyd, work, dist, notes ->
                            viewModel.saveBrainFogLog(sleep, energy, stress, focus, clarity, act, hyd, work, dist, notes)
                        },
                        onDeleteBrainFogEntry = { entry ->
                            viewModel.deleteBrainFogLog(entry)
                        }
                    )
                }

                AppNavDestination.RESET -> {
                    ResetScreen(
                        audioSessions = viewModel.repository.audioSessions,
                        audioState = audioState,
                        onPlaySession = { session -> viewModel.playAudioSession(session) },
                        onPauseAudio = { viewModel.pauseAudio() },
                        onResumeAudio = { viewModel.resumeAudio() },
                        onSeekAudio = { sec -> viewModel.seekAudio(sec) },
                        onVolumeChange = { vol -> viewModel.setAudioVolume(vol) }
                    )
                }

                AppNavDestination.PROFILE -> {
                    ProfileScreen(
                        settings = settings,
                        progress = progress,
                        onUpdateName = { viewModel.updateName(it) },
                        onUpdateReminderTime = { viewModel.updateReminderTime(it) },
                        onToggleNotifications = { viewModel.toggleNotifications(it) },
                        onToggleSoundEffects = { viewModel.toggleSoundEffects(it) },
                        onToggleBackgroundAudio = { viewModel.toggleBackgroundAudio(it) },
                        onToggleVoice = { viewModel.toggleVoice(it) },
                        onRedeemCode = { viewModel.redeemAccessCode(it) },
                        onResetAllProgress = { viewModel.resetAllProgress() },
                        onOpenAdmin = { viewModel.navigateTo(AppNavDestination.ADMIN) }
                    )
                }

                AppNavDestination.ADMIN -> {
                    AdminScreen(
                        progress = progress,
                        notificationStatus = adminStatus,
                        onSendNotification = { title, msg, aud ->
                            viewModel.sendAdminNotification(title, msg, aud)
                        },
                        onClearNotificationStatus = {
                            viewModel.clearAdminNotificationStatus()
                        },
                        onBack = { viewModel.navigateTo(AppNavDestination.PROFILE) }
                    )
                }
            }
        }
    }
}

@Composable
private fun navBarItemColors() = NavigationBarItemDefaults.colors(
    selectedIconColor = SoftSageDark,
    selectedTextColor = SoftSageDark,
    unselectedIconColor = WarmTextMuted,
    unselectedTextColor = WarmTextMuted,
    indicatorColor = WarmCard
)
