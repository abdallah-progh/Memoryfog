package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import com.example.data.model.AudioSession
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.sin

data class AudioPlayerState(
    val currentSession: AudioSession? = null,
    val isPlaying: Boolean = false,
    val currentPositionSec: Int = 0,
    val totalDurationSec: Int = 300,
    val volume: Float = 0.8f,
    val soundEffectsEnabled: Boolean = true,
    val voiceEnabled: Boolean = true,
    val backgroundAudioEnabled: Boolean = true
)

class MentalSharpnessAudioEngine(private val context: Context) {
    private val scope = CoroutineScope(Dispatchers.Default)
    private var playbackJob: Job? = null
    private var timerJob: Job? = null
    private var audioTrack: AudioTrack? = null

    private val _state = MutableStateFlow(AudioPlayerState())
    val state: StateFlow<AudioPlayerState> = _state.asStateFlow()

    private val sampleRate = 44100
    private var isGenerating = false

    fun playSession(session: AudioSession) {
        if (_state.value.currentSession?.id == session.id && _state.value.isPlaying) {
            pause()
            return
        }

        stop()
        _state.value = _state.value.copy(
            currentSession = session,
            isPlaying = true,
            currentPositionSec = 0,
            totalDurationSec = session.durationSec
        )

        startTonePlayback(session.frequencyHz)
        startTimer()
    }

    fun resume() {
        val session = _state.value.currentSession ?: return
        if (!_state.value.isPlaying) {
            _state.value = _state.value.copy(isPlaying = true)
            startTonePlayback(session.frequencyHz)
            startTimer()
        }
    }

    fun pause() {
        _state.value = _state.value.copy(isPlaying = false)
        stopTonePlayback()
        timerJob?.cancel()
    }

    fun seekTo(seconds: Int) {
        val clamped = seconds.coerceIn(0, _state.value.totalDurationSec)
        _state.value = _state.value.copy(currentPositionSec = clamped)
    }

    fun setVolume(vol: Float) {
        val clamped = vol.coerceIn(0f, 1f)
        _state.value = _state.value.copy(volume = clamped)
        audioTrack?.setVolume(clamped)
    }

    fun toggleSoundEffects(enabled: Boolean) {
        _state.value = _state.value.copy(soundEffectsEnabled = enabled)
    }

    fun toggleVoice(enabled: Boolean) {
        _state.value = _state.value.copy(voiceEnabled = enabled)
    }

    fun toggleBackgroundAudio(enabled: Boolean) {
        _state.value = _state.value.copy(backgroundAudioEnabled = enabled)
    }

    fun playChime() {
        if (!_state.value.soundEffectsEnabled) return
        scope.launch {
            try {
                playSingingBowlChime(528.0, 1.2)
            } catch (_: Exception) {}
        }
    }

    private fun startTimer() {
        timerJob?.cancel()
        timerJob = scope.launch {
            while (isActive && _state.value.isPlaying) {
                delay(1000)
                val nextPos = _state.value.currentPositionSec + 1
                if (nextPos >= _state.value.totalDurationSec) {
                    _state.value = _state.value.copy(
                        currentPositionSec = _state.value.totalDurationSec,
                        isPlaying = false
                    )
                    stopTonePlayback()
                    playChime()
                    break
                } else {
                    _state.value = _state.value.copy(currentPositionSec = nextPos)
                }
            }
        }
    }

    private fun startTonePlayback(baseFreq: Double) {
        stopTonePlayback()
        if (!_state.value.backgroundAudioEnabled) return

        isGenerating = true
        playbackJob = scope.launch(Dispatchers.IO) {
            try {
                val bufferSize = AudioTrack.getMinBufferSize(
                    sampleRate,
                    AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                ).coerceAtLeast(sampleRate / 4)

                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(bufferSize)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()

                audioTrack = track
                track.setVolume(_state.value.volume)
                track.play()

                val buffer = ShortArray(bufferSize)
                var phase1 = 0.0
                var phase2 = 0.0
                var phaseLfo = 0.0

                // Harmonic frequencies: Base + fifth + subtle 4Hz binaural wave
                val freq1 = baseFreq
                val freq2 = baseFreq * 1.5 // Perfect fifth for soothing ambient richness
                val lfoFreq = 0.15 // Gentle ocean-like swell

                while (isActive && isGenerating) {
                    for (i in buffer.indices) {
                        val swell = 0.7 + 0.3 * sin(phaseLfo)
                        val sampleVal = (sin(phase1) * 0.65 + sin(phase2) * 0.35) * swell

                        buffer[i] = (sampleVal * 10000).toInt().coerceIn(-32768, 32767).toShort()

                        phase1 += 2 * Math.PI * freq1 / sampleRate
                        if (phase1 > 2 * Math.PI) phase1 -= 2 * Math.PI

                        phase2 += 2 * Math.PI * freq2 / sampleRate
                        if (phase2 > 2 * Math.PI) phase2 -= 2 * Math.PI

                        phaseLfo += 2 * Math.PI * lfoFreq / sampleRate
                        if (phaseLfo > 2 * Math.PI) phaseLfo -= 2 * Math.PI
                    }
                    track.write(buffer, 0, buffer.size)
                }

                track.stop()
                track.release()
            } catch (_: Exception) {
                // Ignore gracefully
            }
        }
    }

    private fun playSingingBowlChime(freq: Double, durationSec: Double) {
        val numSamples = (sampleRate * durationSec).toInt()
        val buffer = ShortArray(numSamples)
        var phase = 0.0

        for (i in 0 until numSamples) {
            val progress = i.toDouble() / numSamples
            val decay = Math.exp(-progress * 4.5) // Exponential acoustic bell decay
            val sampleVal = sin(phase) * decay * 14000
            buffer[i] = sampleVal.toInt().toShort()

            phase += 2 * Math.PI * freq / sampleRate
            if (phase > 2 * Math.PI) phase -= 2 * Math.PI
        }

        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(buffer.size * 2)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()

        track.write(buffer, 0, buffer.size)
        track.play()

        Handler(Looper.getMainLooper()).postDelayed({
            try {
                track.stop()
                track.release()
            } catch (_: Exception) {}
        }, (durationSec * 1000).toLong() + 200)
    }

    private fun stopTonePlayback() {
        isGenerating = false
        playbackJob?.cancel()
        playbackJob = null
        try {
            audioTrack?.pause()
            audioTrack?.flush()
        } catch (_: Exception) {}
    }

    fun stop() {
        pause()
        _state.value = _state.value.copy(
            currentPositionSec = 0,
            isPlaying = false
        )
    }
}
