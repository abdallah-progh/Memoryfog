package com.example.ui.track

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BrainFogEntry
import com.example.data.model.DailyCheckIn
import com.example.ui.components.AccessibleRatingSelector
import com.example.ui.components.MedicalDisclaimerBanner
import com.example.ui.theme.DeepNavy
import com.example.ui.theme.MutedGold
import com.example.ui.theme.SoftSage
import com.example.ui.theme.SoftSageContainer
import com.example.ui.theme.SoftSageDark
import com.example.ui.theme.WarmBorder
import com.example.ui.theme.WarmCard
import com.example.ui.theme.WarmTextMuted
import com.example.ui.theme.WarmTextPrimary
import com.example.ui.theme.WarmWhite

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun TrackScreen(
    checkIns: List<DailyCheckIn>,
    brainFogEntries: List<BrainFogEntry>,
    onSaveBrainFogEntry: (
        sleep: Int, energy: Int, stress: Int, focus: Int, clarity: Int,
        activity: String, hydration: String, workload: String,
        distractions: String, freeNotes: String
    ) -> Unit,
    onDeleteBrainFogEntry: (BrainFogEntry) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var showAddDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(WarmWhite)
            .padding(top = 16.dp)
    ) {
        Column(modifier = Modifier.padding(horizontal = 20.dp)) {
            Text(
                text = "Track & Insights",
                style = MaterialTheme.typography.displayMedium,
                color = DeepNavy
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Observe your natural patterns and daily rhythms without judgment.",
                style = MaterialTheme.typography.bodyMedium,
                color = SoftSageDark
            )
            Spacer(modifier = Modifier.height(16.dp))

            PrimaryTabRow(
                selectedTabIndex = selectedTab,
                containerColor = WarmCard,
                contentColor = DeepNavy,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Overview Trends", fontWeight = FontWeight.SemiBold) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Brain Fog Log", fontWeight = FontWeight.SemiBold) }
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (selectedTab == 0) {
            TrendsOverviewContent(checkIns = checkIns)
        } else {
            BrainFogTrackerContent(
                entries = brainFogEntries,
                onAddNewClick = { showAddDialog = true },
                onDelete = onDeleteBrainFogEntry
            )
        }
    }

    if (showAddDialog) {
        AddBrainFogDialog(
            onDismiss = { showAddDialog = false },
            onSave = { sleep, energy, stress, focus, clarity, activity, hydration, workload, distractions, notes ->
                onSaveBrainFogEntry(sleep, energy, stress, focus, clarity, activity, hydration, workload, distractions, notes)
                showAddDialog = false
            }
        )
    }
}

@Composable
private fun TrendsOverviewContent(
    checkIns: List<DailyCheckIn>
) {
    val recentCheckIns = remember(checkIns) { checkIns.take(7) }

    val avgSleep = if (recentCheckIns.isNotEmpty()) recentCheckIns.map { it.sleepQuality }.average() else 3.5
    val avgEnergy = if (recentCheckIns.isNotEmpty()) recentCheckIns.map { it.energy }.average() else 3.2
    val avgFocus = if (recentCheckIns.isNotEmpty()) recentCheckIns.map { it.focus }.average() else 3.4
    val avgStress = if (recentCheckIns.isNotEmpty()) recentCheckIns.map { it.stress }.average() else 2.8
    val avgClarity = if (recentCheckIns.isNotEmpty()) recentCheckIns.map { it.mentalClarity }.average() else 3.3

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            // Pattern summary card
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .border(1.dp, WarmBorder, RoundedCornerShape(14.dp)),
                color = WarmCard
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "PATTERN OBSERVATION",
                        style = MaterialTheme.typography.labelLarge,
                        color = MutedGold,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (checkIns.size >= 3) {
                            "Your recent entries show a calm pattern worth noticing. Focus and clarity correlate directly with nights of restful sleep and unhurried morning transitions."
                        } else {
                            "Log a few daily check-ins on the Home screen to reveal your 7-day mental clarity and focus rhythms."
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = WarmTextPrimary,
                        lineHeight = 22.sp
                    )
                }
            }
        }

        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .border(1.dp, WarmBorder, RoundedCornerShape(14.dp)),
                color = Color.White
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "7-Day Metric Averages",
                        style = MaterialTheme.typography.titleLarge,
                        color = DeepNavy,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    MetricBar(label = "Mental Clarity", score = avgClarity, color = SoftSageDark)
                    Spacer(modifier = Modifier.height(14.dp))
                    MetricBar(label = "Focus & Attention", score = avgFocus, color = DeepNavy)
                    Spacer(modifier = Modifier.height(14.dp))
                    MetricBar(label = "Restful Sleep", score = avgSleep, color = SoftSage)
                    Spacer(modifier = Modifier.height(14.dp))
                    MetricBar(label = "Daily Energy", score = avgEnergy, color = MutedGold)
                    Spacer(modifier = Modifier.height(14.dp))
                    MetricBar(label = "Stress Load (1=Heavy, 5=Calm)", score = avgStress, color = Color(0xFF6A8CA6))
                }
            }
        }

        item {
            MedicalDisclaimerBanner()
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
private fun MetricBar(
    label: String,
    score: Double,
    color: Color
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium,
                color = WarmTextPrimary,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = String.format("%.1f / 5.0", score),
                style = MaterialTheme.typography.labelLarge,
                color = color,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        LinearProgressIndicator(
            progress = { (score.toFloat() / 5f).coerceIn(0f, 1f) },
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(CircleShape),
            color = color,
            trackColor = WarmCard
        )
    }
}

@Composable
private fun BrainFogTrackerContent(
    entries: List<BrainFogEntry>,
    onAddNewClick: () -> Unit,
    onDelete: (BrainFogEntry) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Button(
                onClick = onAddNewClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("add_fog_entry_button"),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = DeepNavy,
                    contentColor = Color.White
                )
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Log Mental State / Brain Fog Moment", fontWeight = FontWeight.SemiBold)
            }
        }

        if (entries.isEmpty()) {
            item {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 24.dp)
                        .clip(RoundedCornerShape(12.dp)),
                    color = WarmCard
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(text = "📝", fontSize = 32.sp)
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "No Brain Fog Logs Yet",
                            style = MaterialTheme.typography.titleMedium,
                            color = DeepNavy,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Whenever you notice a bout of afternoon brain fog or scattered focus, tap above to note recent hydration, meals, and distractions.",
                            style = MaterialTheme.typography.bodySmall,
                            color = WarmTextMuted,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            }
        } else {
            items(entries) { entry ->
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .border(1.dp, WarmBorder, RoundedCornerShape(14.dp)),
                    color = Color.White
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = entry.dateDisplay,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = DeepNavy,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = entry.timeDisplay,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = WarmTextMuted
                                )
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = if (entry.clarityRating <= 2) Color(0xFFFDE8E8) else SoftSageContainer
                                ) {
                                    Text(
                                        text = "Clarity: ${entry.clarityRating}/5",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (entry.clarityRating <= 2) Color(0xFF9B1C1C) else SoftSageDark,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                                IconButton(
                                    onClick = { onDelete(entry) },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Delete entry",
                                        tint = WarmTextMuted,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        if (entry.recentActivity.isNotEmpty()) {
                            Text(
                                text = "Activity: ${entry.recentActivity}",
                                style = MaterialTheme.typography.bodySmall,
                                color = WarmTextPrimary
                            )
                        }
                        if (entry.hydrationMeals.isNotEmpty()) {
                            Text(
                                text = "Hydration/Meals: ${entry.hydrationMeals}",
                                style = MaterialTheme.typography.bodySmall,
                                color = WarmTextPrimary
                            )
                        }
                        if (entry.distractions.isNotEmpty()) {
                            Text(
                                text = "Distractions: ${entry.distractions}",
                                style = MaterialTheme.typography.bodySmall,
                                color = WarmTextPrimary
                            )
                        }
                        if (entry.freeNotes.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "\"${entry.freeNotes}\"",
                                style = MaterialTheme.typography.bodySmall,
                                color = WarmTextMuted,
                                fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                            )
                        }
                    }
                }
            }
        }

        item {
            MedicalDisclaimerBanner()
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
private fun AddBrainFogDialog(
    onDismiss: () -> Unit,
    onSave: (
        sleep: Int, energy: Int, stress: Int, focus: Int, clarity: Int,
        activity: String, hydration: String, workload: String,
        distractions: String, freeNotes: String
    ) -> Unit
) {
    var sleep by remember { mutableIntStateOf(3) }
    var energy by remember { mutableIntStateOf(3) }
    var stress by remember { mutableIntStateOf(3) }
    var focus by remember { mutableIntStateOf(2) }
    var clarity by remember { mutableIntStateOf(2) }
    var activity by remember { mutableStateOf("") }
    var hydration by remember { mutableStateOf("") }
    var workload by remember { mutableStateOf("Moderate") }
    var distractions by remember { mutableStateOf("") }
    var freeNotes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Log Mental State / Fog",
                style = MaterialTheme.typography.headlineSmall,
                color = DeepNavy
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(androidx.compose.foundation.rememberScrollState())
            ) {
                Text(
                    text = "Observe what accompanied this feeling:",
                    style = MaterialTheme.typography.bodySmall,
                    color = WarmTextMuted
                )
                Spacer(modifier = Modifier.height(12.dp))

                AccessibleRatingSelector(
                    label = "Mental Clarity",
                    currentValue = clarity,
                    onValueSelected = { clarity = it },
                    lowLabel = "Heavy Fog",
                    highLabel = "Crisp"
                )
                Spacer(modifier = Modifier.height(12.dp))

                AccessibleRatingSelector(
                    label = "Focus Ability",
                    currentValue = focus,
                    onValueSelected = { focus = it },
                    lowLabel = "Scattered",
                    highLabel = "Locked In"
                )
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = activity,
                    onValueChange = { activity = it },
                    label = { Text("Recent Activity") },
                    placeholder = { Text("e.g. 2 hours on spreadsheet, meetings") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = hydration,
                    onValueChange = { hydration = it },
                    label = { Text("Hydration & Meals") },
                    placeholder = { Text("e.g. coffee only, pasta lunch, 1 glass water") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = distractions,
                    onValueChange = { distractions = it },
                    label = { Text("Noticed Distractions") },
                    placeholder = { Text("e.g. email notifications, poor room air") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = freeNotes,
                    onValueChange = { freeNotes = it },
                    label = { Text("Personal Notes / Sensation") },
                    placeholder = { Text("Brief reflection...") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(sleep, energy, stress, focus, clarity, activity, hydration, workload, distractions, freeNotes)
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = DeepNavy,
                    contentColor = Color.White
                )
            ) {
                Text("Save Log")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = WarmTextMuted)
            }
        }
    )
}
