package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = SoftSageLight,
    onPrimary = DeepNavy,
    primaryContainer = DeepNavyContainer,
    onPrimaryContainer = SoftSageLight,
    secondary = MutedGold,
    onSecondary = DeepNavy,
    secondaryContainer = DeepNavySurface,
    onSecondaryContainer = MutedGoldLight,
    tertiary = CalmSky,
    onTertiary = DeepNavy,
    background = DeepNavy,
    onBackground = WarmWhite,
    surface = DeepNavySurface,
    onSurface = WarmWhite,
    surfaceVariant = DeepNavyContainer,
    onSurfaceVariant = WarmCard,
    outline = DeepNavyLight
)

private val LightColorScheme = lightColorScheme(
    primary = SoftSageDark,
    onPrimary = Color.White,
    primaryContainer = SoftSageContainer,
    onPrimaryContainer = SoftSageDark,
    secondary = MutedGold,
    onSecondary = Color.White,
    secondaryContainer = MutedGoldLight,
    onSecondaryContainer = MutedGoldDark,
    tertiary = DeepNavy,
    onTertiary = WarmWhite,
    background = WarmWhite,
    onBackground = WarmTextPrimary,
    surface = Color.White,
    onSurface = WarmTextPrimary,
    surfaceVariant = WarmCard,
    onSurfaceVariant = WarmTextMuted,
    outline = WarmBorder
)

@Composable
fun MentalSharpnessTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
