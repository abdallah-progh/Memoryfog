package com.example.ui.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UserSettings
import com.example.ui.ProgressSummary
import com.example.ui.components.MedicalDisclaimerBanner
import com.example.ui.theme.DeepNavy
import com.example.ui.theme.MutedGold
import com.example.ui.theme.SoftSage
import com.example.ui.theme.SoftSageContainer
import com.example.ui.theme.SoftSageDark
import com.example.ui.theme.WarmBorder
import com.example.ui.theme.WarmCard
import com.example.ui.theme.WarmTextMuted
import com.example.ui.theme.WarmTextPrimary
import com.example.ui.theme.WarmWhite

@Composable
fun ProfileScreen(
    settings: UserSettings,
    progress: ProgressSummary,
    onUpdateName: (String) -> Unit,
    onUpdateReminderTime: (String) -> Unit,
    onToggleNotifications: (Boolean) -> Unit,
    onToggleSoundEffects: (Boolean) -> Unit,
    onToggleBackgroundAudio: (Boolean) -> Unit,
    onToggleVoice: (Boolean) -> Unit,
    onRedeemCode: (String) -> Boolean,
    onResetAllProgress: () -> Unit,
    onOpenAdmin: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showNameDialog by remember { mutableStateOf(false) }
    var showTimeDialog by remember { mutableStateOf(false) }
    var showCodeDialog by remember { mutableStateOf(false) }
    var showResetConfirmDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(WarmWhite)
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "Profile & Settings",
                style = MaterialTheme.typography.displayMedium,
                color = DeepNavy
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Manage your preferences, reminders, and lifetime routines.",
                style = MaterialTheme.typography.bodyMedium,
                color = SoftSageDark
            )
        }

        // User identity card
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .border(1.dp, WarmBorder, RoundedCornerShape(14.dp)),
                color = Color.White
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .background(SoftSageContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = settings.userName.take(1).uppercase(),
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold,
                                color = SoftSageDark
                            )
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column {
                            Text(
                                text = settings.userName,
                                style = MaterialTheme.typography.titleLarge,
                                color = DeepNavy,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Day ${progress.currentDay} • ${progress.completedCount}/30 Completed",
                                style = MaterialTheme.typography.bodySmall,
                                color = WarmTextMuted
                            )
                        }
                    }

                    IconButton(
                        onClick = { showNameDialog = true },
                        modifier = Modifier.testTag("edit_name_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Edit name",
                            tint = SoftSageDark
                        )
                    }
                }
            }
        }

        // Post-30-Day "Keep Going" Section
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .border(1.dp, WarmBorder, RoundedCornerShape(14.dp)),
                color = WarmCard
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "POST-30-DAY: KEEP GOING",
                            style = MaterialTheme.typography.labelLarge,
                            color = MutedGold,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = SoftSageContainer
                        ) {
                            Text(
                                text = "LIFELONG ANCHORS",
                                style = MaterialTheme.typography.labelSmall,
                                color = SoftSageDark,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Your 3 Core Habits For Daily Clarity:",
                        style = MaterialTheme.typography.titleMedium,
                        color = DeepNavy,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    settings.personalAnchorHabits.forEachIndexed { idx, habit ->
                        Row(
                            modifier = Modifier.padding(vertical = 3.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(20.dp)
                                    .clip(CircleShape)
                                    .background(SoftSageDark),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "${idx + 1}",
                                    fontSize = 11.sp,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = habit,
                                style = MaterialTheme.typography.bodyMedium,
                                color = WarmTextPrimary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Tip on busy days: Shrink each anchor to your 2-minute minimum version so your chain remains intact.",
                        style = MaterialTheme.typography.bodySmall,
                        color = WarmTextMuted,
                        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                    )
                }
            }
        }

        // Daily Reminder Settings
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .border(1.dp, WarmBorder, RoundedCornerShape(14.dp)),
                color = Color.White
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "Daily Routine Cues",
                        style = MaterialTheme.typography.titleMedium,
                        color = DeepNavy,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Daily Prompt",
                                style = MaterialTheme.typography.bodyLarge,
                                color = WarmTextPrimary
                            )
                            Text(
                                text = "Scheduled at ${settings.reminderTime}",
                                style = MaterialTheme.typography.bodySmall,
                                color = WarmTextMuted
                            )
                        }
                        OutlinedButton(
                            onClick = { showTimeDialog = true },
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Change Time")
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Gentle Notifications",
                            style = MaterialTheme.typography.bodyLarge,
                            color = WarmTextPrimary
                        )
                        Switch(
                            checked = settings.notificationsEnabled,
                            onCheckedChange = onToggleNotifications,
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = SoftSageDark
                            )
                        )
                    }
                }
            }
        }

        // Audio & Atmosphere
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .border(1.dp, WarmBorder, RoundedCornerShape(14.dp)),
                color = Color.White
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "Audio & Sound Preferences",
                        style = MaterialTheme.typography.titleMedium,
                        color = DeepNavy,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Singing Bowl Chime Sounds",
                            style = MaterialTheme.typography.bodyLarge,
                            color = WarmTextPrimary
                        )
                        Switch(
                            checked = settings.soundEffectsEnabled,
                            onCheckedChange = onToggleSoundEffects,
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = SoftSageDark
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Ambient Synthesized Waves (432Hz)",
                            style = MaterialTheme.typography.bodyLarge,
                            color = WarmTextPrimary
                        )
                        Switch(
                            checked = settings.backgroundAudioEnabled,
                            onCheckedChange = onToggleBackgroundAudio,
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = SoftSageDark
                            )
                        )
                    }
                }
            }
        }

        // Access Code Redemption Card
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .border(1.dp, WarmBorder, RoundedCornerShape(14.dp)),
                color = if (settings.isAccessUnlocked) SoftSageContainer else Color.White
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.LockOpen,
                                contentDescription = null,
                                tint = if (settings.isAccessUnlocked) SoftSageDark else MutedGold,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (settings.isAccessUnlocked) "Full Access Active" else "Redeem Access Code",
                                style = MaterialTheme.typography.titleMedium,
                                color = DeepNavy,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (settings.isAccessUnlocked) {
                                "Code: ${settings.accessCodeUsed} • Lifetime Companion"
                            } else {
                                "Have a Gumroad or website access code? Enter here."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = WarmTextMuted
                        )
                    }

                    if (!settings.isAccessUnlocked) {
                        Button(
                            onClick = { showCodeDialog = true },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = DeepNavy,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Redeem")
                        }
                    }
                }
            }
        }

        // Admin & Management Tools
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .border(1.dp, WarmBorder, RoundedCornerShape(14.dp)),
                color = Color.White
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "App Management & Admin",
                        style = MaterialTheme.typography.titleMedium,
                        color = DeepNavy,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Admin & Campaign Dashboard",
                            style = MaterialTheme.typography.bodyLarge,
                            color = WarmTextPrimary
                        )
                        OutlinedButton(
                            onClick = onOpenAdmin,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("admin_open_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.AdminPanelSettings,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Open Admin")
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Restart 30-Day Cycle",
                            style = MaterialTheme.typography.bodyLarge,
                            color = WarmTextPrimary
                        )
                        OutlinedButton(
                            onClick = { showResetConfirmDialog = true },
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Reset", color = Color(0xFFC04040))
                        }
                    }
                }
            }
        }

        item {
            MedicalDisclaimerBanner()
            Spacer(modifier = Modifier.height(20.dp))
        }
    }

    // Edit Name Dialog
    if (showNameDialog) {
        var newName by remember { mutableStateOf(settings.userName) }
        AlertDialog(
            onDismissRequest = { showNameDialog = false },
            title = { Text("Update Name") },
            text = {
                OutlinedTextField(
                    value = newName,
                    onValueChange = { newName = it },
                    label = { Text("Your Name") },
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newName.isNotBlank()) onUpdateName(newName.trim())
                        showNameDialog = false
                    }
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showNameDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Change Reminder Time Dialog
    if (showTimeDialog) {
        val times = listOf("07:00 AM", "08:00 AM", "08:30 AM", "09:00 AM", "12:30 PM", "06:30 PM")
        AlertDialog(
            onDismissRequest = { showTimeDialog = false },
            title = { Text("Select Reminder Time") },
            text = {
                Column {
                    times.forEach { time ->
                        Text(
                            text = time,
                            style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onUpdateReminderTime(time)
                                    showTimeDialog = false
                                }
                                .padding(vertical = 12.dp)
                        )
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showTimeDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Redeem Code Dialog
    if (showCodeDialog) {
        var inputCode by remember { mutableStateOf("") }
        var errorMessage by remember { mutableStateOf<String?>(null) }

        AlertDialog(
            onDismissRequest = { showCodeDialog = false },
            title = { Text("Redeem Access Code") },
            text = {
                Column {
                    Text(
                        text = "Enter your Gumroad license key or promotion code:",
                        style = MaterialTheme.typography.bodySmall,
                        color = WarmTextMuted
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = inputCode,
                        onValueChange = {
                            inputCode = it
                            errorMessage = null
                        },
                        label = { Text("Access Code") },
                        placeholder = { Text("e.g. SHARP40, RESET2026") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (errorMessage != null) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = errorMessage ?: "",
                            color = Color.Red,
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val success = onRedeemCode(inputCode)
                        if (success) {
                            showCodeDialog = false
                        } else {
                            errorMessage = "Please enter a valid code."
                        }
                    }
                ) {
                    Text("Unlock")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCodeDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Reset Progress Confirmation Dialog
    if (showResetConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showResetConfirmDialog = false },
            title = { Text("Reset 30-Day Progress?") },
            text = {
                Text(
                    text = "This will clear all completed days, check-in history, and notes, allowing you to start fresh on Day 1.",
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onResetAllProgress()
                        showResetConfirmDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFC04040)
                    )
                ) {
                    Text("Confirm Reset")
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetConfirmDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
