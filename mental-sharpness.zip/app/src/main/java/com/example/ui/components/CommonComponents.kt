package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.AudioPlayerState
import com.example.ui.theme.DeepNavy
import com.example.ui.theme.DeepNavySurface
import com.example.ui.theme.MutedGold
import com.example.ui.theme.SoftSage
import com.example.ui.theme.SoftSageContainer
import com.example.ui.theme.SoftSageDark
import com.example.ui.theme.SoftSageLight
import com.example.ui.theme.WarmBorder
import com.example.ui.theme.WarmCard
import com.example.ui.theme.WarmTextMuted
import com.example.ui.theme.WarmTextPrimary
import com.example.ui.theme.WarmWhite

@Composable
fun MedicalDisclaimerBanner(
    modifier: Modifier = Modifier,
    isExpandedDefault: Boolean = false
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .border(1.dp, WarmBorder, RoundedCornerShape(12.dp)),
        color = WarmCard
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.Top
        ) {
            Icon(
                imageVector = Icons.Default.Info,
                contentDescription = "Medical and Educational Disclaimer",
                tint = SoftSageDark,
                modifier = Modifier
                    .size(20.dp)
                    .padding(top = 2.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = "Educational & Wellness Disclaimer",
                    style = MaterialTheme.typography.labelLarge,
                    color = WarmTextPrimary,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = "This companion app provides general educational and lifestyle habit information. It is not medical advice and is not intended to diagnose, treat, cure, or prevent any medical condition. For persistent or severe cognitive concerns, always consult a qualified healthcare professional.",
                    style = MaterialTheme.typography.bodySmall,
                    color = WarmTextMuted,
                    lineHeight = 18.sp
                )
            }
        }
    }
}

@Composable
fun AccessibleRatingSelector(
    label: String,
    currentValue: Int,
    onValueSelected: (Int) -> Unit,
    modifier: Modifier = Modifier,
    lowLabel: String = "Low",
    highLabel: String = "High"
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.titleMedium,
                color = WarmTextPrimary,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = "$currentValue / 5",
                style = MaterialTheme.typography.labelLarge,
                color = SoftSageDark,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            (1..5).forEach { score ->
                val isSelected = score == currentValue
                val bgColor = if (isSelected) SoftSageDark else WarmCard
                val contentColor = if (isSelected) Color.White else WarmTextPrimary
                val borderColor = if (isSelected) SoftSageDark else WarmBorder

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp) // Accessibility min touch target
                        .clip(RoundedCornerShape(8.dp))
                        .background(bgColor)
                        .border(1.dp, borderColor, RoundedCornerShape(8.dp))
                        .clickable { onValueSelected(score) }
                        .testTag("rating_${label.lowercase()}_$score"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = score.toString(),
                        fontSize = 18.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = contentColor
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "1: $lowLabel",
                style = MaterialTheme.typography.labelSmall,
                color = WarmTextMuted
            )
            Text(
                text = "5: $highLabel",
                style = MaterialTheme.typography.labelSmall,
                color = WarmTextMuted
            )
        }
    }
}

@Composable
fun ConsistencyStreakCard(
    currentStreak: Int,
    longestStreak: Int,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .border(1.dp, WarmBorder, RoundedCornerShape(14.dp)),
        color = WarmWhite
    ) {
        Row(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(MutedGold.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "☀️",
                        fontSize = 22.sp
                    )
                }
                Spacer(modifier = Modifier.width(14.dp))
                Column {
                    Text(
                        text = if (currentStreak > 0) "$currentStreak Day Consistency" else "Start Your Consistency",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = DeepNavy
                    )
                    Text(
                        text = if (currentStreak > 0) "Keep the daily rhythm alive" else "Small steps today create lasting clarity",
                        style = MaterialTheme.typography.bodySmall,
                        color = WarmTextMuted
                    )
                }
            }

            Surface(
                shape = RoundedCornerShape(8.dp),
                color = SoftSageContainer,
                modifier = Modifier.padding(start = 8.dp)
            ) {
                Text(
                    text = "Best: $longestStreak d",
                    style = MaterialTheme.typography.labelMedium,
                    color = SoftSageDark,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                )
            }
        }
    }
}

@Composable
fun MiniAudioPlayerBar(
    audioState: AudioPlayerState,
    onResume: () -> Unit,
    onPause: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(
        visible = audioState.currentSession != null,
        enter = fadeIn(),
        exit = fadeOut()
    ) {
        val session = audioState.currentSession ?: return@AnimatedVisibility

        Surface(
            modifier = modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .clip(RoundedCornerShape(14.dp))
                .border(1.dp, WarmBorder, RoundedCornerShape(14.dp)),
            color = DeepNavy,
            shadowElevation = 6.dp
        ) {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(SoftSage.copy(alpha = 0.3f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.VolumeUp,
                                contentDescription = "Playing Audio",
                                tint = SoftSage,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = session.title,
                                style = MaterialTheme.typography.labelLarge,
                                color = Color.White,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            val elapsedMin = audioState.currentPositionSec / 60
                            val elapsedSec = audioState.currentPositionSec % 60
                            val totalMin = audioState.totalDurationSec / 60
                            val totalSec = audioState.totalDurationSec % 60
                            Text(
                                text = String.format("%02d:%02d / %02d:%02d", elapsedMin, elapsedSec, totalMin, totalSec),
                                style = MaterialTheme.typography.labelSmall,
                                color = SoftSageLight
                            )
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = {
                                if (audioState.isPlaying) onPause() else onResume()
                            },
                            modifier = Modifier.size(44.dp)
                        ) {
                            Icon(
                                imageVector = if (audioState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = if (audioState.isPlaying) "Pause" else "Play",
                                tint = Color.White,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                        IconButton(
                            onClick = onClose,
                            modifier = Modifier.size(40.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close Player",
                                tint = WarmTextMuted,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }

                val progress = if (audioState.totalDurationSec > 0) {
                    audioState.currentPositionSec.toFloat() / audioState.totalDurationSec.toFloat()
                } else 0f

                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(3.dp),
                    color = SoftSage,
                    trackColor = DeepNavySurface
                )
            }
        }
    }
}
