package com.example.ui.reset

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.AudioPlayerState
import com.example.data.model.AudioCategory
import com.example.data.model.AudioSession
import com.example.ui.components.MedicalDisclaimerBanner
import com.example.ui.theme.DeepNavy
import com.example.ui.theme.MutedGold
import com.example.ui.theme.SoftSage
import com.example.ui.theme.SoftSageContainer
import com.example.ui.theme.SoftSageDark
import com.example.ui.theme.WarmBorder
import com.example.ui.theme.WarmCard
import com.example.ui.theme.WarmTextMuted
import com.example.ui.theme.WarmTextPrimary
import com.example.ui.theme.WarmWhite

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun ResetScreen(
    audioSessions: List<AudioSession>,
    audioState: AudioPlayerState,
    onPlaySession: (AudioSession) -> Unit,
    onPauseAudio: () -> Unit,
    onResumeAudio: () -> Unit,
    onSeekAudio: (Int) -> Unit,
    onVolumeChange: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    var isGuidedModeActive by remember { mutableStateOf(false) }
    var selectedCategoryIndex by remember { mutableIntStateOf(0) }

    val categories = listOf("All", "Reset", "Focus", "Breathing", "Sleep", "Mindful Pause")

    val filteredSessions = remember(selectedCategoryIndex, audioSessions) {
        when (selectedCategoryIndex) {
            1 -> audioSessions.filter { it.category == AudioCategory.RESET }
            2 -> audioSessions.filter { it.category == AudioCategory.FOCUS }
            3 -> audioSessions.filter { it.category == AudioCategory.BREATHING }
            4 -> audioSessions.filter { it.category == AudioCategory.SLEEP }
            5 -> audioSessions.filter { it.category == AudioCategory.MINDFUL_PAUSE }
            else -> audioSessions
        }
    }

    if (isGuidedModeActive) {
        Guided5MinuteResetView(
            onFinish = { isGuidedModeActive = false },
            onPlayAudio = {
                val resetTrack = audioSessions.firstOrNull { it.id == "audio_reset_5" } ?: audioSessions.first()
                onPlaySession(resetTrack)
            }
        )
    } else {
        Column(
            modifier = modifier
                .fillMaxSize()
                .background(WarmWhite)
                .padding(top = 16.dp)
        ) {
            Column(modifier = Modifier.padding(horizontal = 20.dp)) {
                Text(
                    text = "Mental Reset & Audio",
                    style = MaterialTheme.typography.displayMedium,
                    color = DeepNavy
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "A gentle circuit breaker to release tension and refocus anytime.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = SoftSageDark
                )

                Spacer(modifier = Modifier.height(18.dp))

                // Hero Guided Reset Card
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .border(1.dp, WarmBorder, RoundedCornerShape(16.dp)),
                    color = DeepNavy
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "NEED A MENTAL RESET?",
                                style = MaterialTheme.typography.labelLarge,
                                color = MutedGold,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = Color.White.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = "5 MIN",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "\"Take five minutes. Start again.\"",
                            style = MaterialTheme.typography.headlineLarge,
                            color = Color.White
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "7 sequential micro-steps to release scattered thoughts, regulate breathing, and select one clear priority.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = WarmWhite.copy(alpha = 0.85f),
                            lineHeight = 22.sp
                        )

                        Spacer(modifier = Modifier.height(18.dp))

                        Button(
                            onClick = { isGuidedModeActive = true },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("start_5min_reset_button"),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = SoftSageDark,
                                contentColor = Color.White
                            )
                        ) {
                            Icon(
                                imageVector = Icons.Default.SelfImprovement,
                                contentDescription = null,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "START 5-MINUTE RESET",
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Text(
                    text = "Audio Sessions Suite",
                    style = MaterialTheme.typography.titleLarge,
                    color = DeepNavy,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(8.dp))

                PrimaryTabRow(
                    selectedTabIndex = selectedCategoryIndex,
                    containerColor = WarmCard,
                    contentColor = DeepNavy,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                ) {
                    categories.take(3).forEachIndexed { index, name ->
                        Tab(
                            selected = selectedCategoryIndex == index,
                            onClick = { selectedCategoryIndex = index },
                            text = { Text(name, style = MaterialTheme.typography.labelMedium) }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredSessions) { session ->
                    val isCurrentPlaying = audioState.currentSession?.id == session.id && audioState.isPlaying

                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .border(
                                width = if (isCurrentPlaying) 1.5.dp else 1.dp,
                                color = if (isCurrentPlaying) SoftSageDark else WarmBorder,
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clickable {
                                if (isCurrentPlaying) onPauseAudio() else onPlaySession(session)
                            }
                            .testTag("audio_session_${session.id}"),
                        color = if (isCurrentPlaying) SoftSageContainer else Color.White
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(42.dp)
                                        .clip(CircleShape)
                                        .background(
                                            if (isCurrentPlaying) SoftSageDark else DeepNavy
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (isCurrentPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                        contentDescription = "Play/Pause",
                                        tint = Color.White,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.width(14.dp))

                                Column {
                                    Text(
                                        text = session.title,
                                        style = MaterialTheme.typography.titleMedium,
                                        color = DeepNavy,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "${session.durationSec / 60} mins • ${session.subtitle}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = WarmTextMuted,
                                        maxLines = 1
                                    )
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = WarmCard
                            ) {
                                Text(
                                    text = session.category.displayName,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = SoftSageDark,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(8.dp))
                    MedicalDisclaimerBanner()
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
    }
}

@Composable
fun Guided5MinuteResetView(
    onFinish: () -> Unit,
    onPlayAudio: () -> Unit,
    modifier: Modifier = Modifier
) {
    var step by remember { mutableIntStateOf(1) }

    val resetSteps = listOf(
        "STEP 1: Pause" to "Stop everything you are doing right now. Drop your hands into your lap. Notice your feet touching the floor.",
        "STEP 2: Take a Slow Breath" to "Inhale slowly through your nose for 4 counts... feel your ribs expand... hold for 2... and release smoothly for 6 counts.",
        "STEP 3: Notice What Pulls Attention" to "Identify the single thought, urgency, or email pulling your energy right now. Simply acknowledge it: 'I see you. You can wait.'",
        "STEP 4: Choose ONE Priority" to "What is the single most useful thing you could do in the next 30 minutes? Not three things. Just ONE.",
        "STEP 5: Remove One Distraction" to "Close secondary tabs, turn your phone face-down, or put on headphones. Give yourself permission to be unreachable for 25 minutes.",
        "STEP 6: Make The First Step Easier" to "Lower the barrier: write the very first sentence, open only the necessary file, or clear the immediate space in front of you.",
        "STEP 7: Begin" to "You have cleared the noise. Take one final grounding breath and begin with calm, unhurried presence."
    )

    val currentStepData = resetSteps.getOrNull(step - 1) ?: resetSteps.first()

    // Breathing circle pulse animation for Step 2
    val infiniteTransition = rememberInfiniteTransition(label = "breathing")
    val breathScale by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "breath_scale"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(WarmWhite)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Step indicator bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 16.dp),
            horizontalArrangement = Arrangement.Center
        ) {
            (1..7).forEach { idx ->
                Box(
                    modifier = Modifier
                        .padding(horizontal = 3.dp)
                        .height(4.dp)
                        .width(if (idx == step) 28.dp else 16.dp)
                        .clip(CircleShape)
                        .background(if (idx <= step) SoftSageDark else WarmBorder)
                )
            }
        }

        // Main step center
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            if (step == 2) {
                // Breathing circle visual
                Box(
                    modifier = Modifier
                        .size(160.dp)
                        .scale(breathScale)
                        .clip(CircleShape)
                        .background(SoftSageContainer)
                        .border(2.dp, SoftSageDark, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (breathScale > 1.05f) "Exhale Slow" else "Inhale Deep",
                        style = MaterialTheme.typography.titleMedium,
                        color = SoftSageDark,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(28.dp))
            } else {
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .clip(CircleShape)
                        .background(SoftSageContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = "🧘", fontSize = 32.sp)
                }
                Spacer(modifier = Modifier.height(24.dp))
            }

            Text(
                text = currentStepData.first,
                style = MaterialTheme.typography.headlineLarge,
                color = DeepNavy,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(16.dp))

            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .border(1.dp, WarmBorder, RoundedCornerShape(14.dp)),
                color = WarmCard
            ) {
                Text(
                    text = currentStepData.second,
                    style = MaterialTheme.typography.bodyLarge,
                    color = WarmTextPrimary,
                    textAlign = TextAlign.Center,
                    lineHeight = 26.sp,
                    modifier = Modifier.padding(20.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            OutlinedButton(
                onClick = onPlayAudio,
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("Play 432Hz Calm Audio Pacer")
            }
        }

        // Navigation buttons
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (step > 1) {
                OutlinedButton(
                    onClick = { step -= 1 },
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("Back")
                }
            }

            Button(
                onClick = {
                    if (step < 7) {
                        step += 1
                    } else {
                        onFinish()
                    }
                },
                modifier = Modifier
                    .weight(if (step > 1) 2f else 1f)
                    .height(50.dp)
                    .testTag("reset_step_button"),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = DeepNavy,
                    contentColor = Color.White
                )
            ) {
                Text(
                    text = if (step == 7) "Finish Reset" else "Next Step",
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
