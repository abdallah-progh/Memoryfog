package com.example.ui.home

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.DayLesson
import com.example.data.model.UserSettings
import com.example.ui.ProgressSummary
import com.example.ui.components.AccessibleRatingSelector
import com.example.ui.components.ConsistencyStreakCard
import com.example.ui.components.MedicalDisclaimerBanner
import com.example.ui.theme.DeepNavy
import com.example.ui.theme.DeepNavyContainer
import com.example.ui.theme.MutedGold
import com.example.ui.theme.SoftSage
import com.example.ui.theme.SoftSageContainer
import com.example.ui.theme.SoftSageDark
import com.example.ui.theme.WarmBorder
import com.example.ui.theme.WarmCard
import com.example.ui.theme.WarmTextMuted
import com.example.ui.theme.WarmTextPrimary
import com.example.ui.theme.WarmWhite
import java.util.Calendar

@Composable
fun HomeScreen(
    settings: UserSettings,
    progress: ProgressSummary,
    todayLesson: DayLesson,
    onStartToday: (Int) -> Unit,
    onOpenReset: () -> Unit,
    onSaveCheckIn: (sleep: Int, energy: Int, focus: Int, stress: Int, clarity: Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    var sleepRating by remember { mutableIntStateOf(3) }
    var energyRating by remember { mutableIntStateOf(3) }
    var focusRating by remember { mutableIntStateOf(3) }
    var stressRating by remember { mutableIntStateOf(3) }
    var clarityRating by remember { mutableIntStateOf(3) }
    var checkInSaved by remember { mutableStateOf(false) }

    val greeting = remember {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        when {
            hour < 12 -> "Good morning"
            hour < 17 -> "Good afternoon"
            else -> "Good evening"
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(WarmWhite)
            .verticalScroll(scrollState)
            .padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        // Top Greeting
        Text(
            text = "$greeting, ${settings.userName}",
            style = MaterialTheme.typography.displayMedium,
            color = DeepNavy
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Mental Sharpness 30-Day Reset",
            style = MaterialTheme.typography.labelLarge,
            color = SoftSageDark,
            letterSpacing = 1.sp
        )

        Spacer(modifier = Modifier.height(18.dp))

        // Progress bar card
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .border(1.dp, WarmBorder, RoundedCornerShape(14.dp)),
            color = Color.White
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "DAY ${progress.currentDay} OF 30",
                        style = MaterialTheme.typography.labelLarge,
                        color = MutedGold,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "${progress.completedCount} / 30 completed",
                        style = MaterialTheme.typography.labelMedium,
                        color = WarmTextMuted
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                LinearProgressIndicator(
                    progress = { (progress.completedCount.toFloat() / 30f).coerceIn(0f, 1f) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(CircleShape),
                    color = SoftSageDark,
                    trackColor = WarmCard
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Hero Banner Image
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .height(120.dp)
                .clip(RoundedCornerShape(14.dp)),
            color = DeepNavyContainer
        ) {
            Image(
                painter = painterResource(id = R.drawable.hero_wellness_editorial),
                contentDescription = "Mental Clarity and Calm",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // MAIN CARD: TODAY'S FOCUS
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .border(1.dp, WarmBorder, RoundedCornerShape(16.dp)),
            color = DeepNavy
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "TODAY'S FOCUS",
                        style = MaterialTheme.typography.labelLarge,
                        color = MutedGold,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.5.sp
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color.White.copy(alpha = 0.12f))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Timer,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${todayLesson.estimatedMinutes} MIN",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "Day ${todayLesson.dayNumber}: ${todayLesson.title}",
                    style = MaterialTheme.typography.headlineLarge,
                    color = Color.White
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = todayLesson.whyItMatters,
                    style = MaterialTheme.typography.bodyMedium,
                    color = WarmWhite.copy(alpha = 0.85f),
                    lineHeight = 22.sp,
                    maxLines = 3
                )

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = { onStartToday(todayLesson.dayNumber) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("start_today_button"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = SoftSageDark,
                        contentColor = Color.White
                    )
                ) {
                    Text(
                        text = "START TODAY",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(
                        imageVector = Icons.Default.ArrowForward,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // STREAK CARD
        ConsistencyStreakCard(
            currentStreak = progress.currentStreak,
            longestStreak = progress.longestStreak
        )

        Spacer(modifier = Modifier.height(16.dp))

        // 5-MINUTE RESET QUICK LAUNCHER
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .border(1.dp, SoftSageDark.copy(alpha = 0.2f), RoundedCornerShape(14.dp)),
            color = SoftSageContainer
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(SoftSageDark),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.SelfImprovement,
                            contentDescription = "Mental Reset",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Need a Mental Reset?",
                            style = MaterialTheme.typography.titleMedium,
                            color = SoftSageDark,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Take 5 minutes. Start again.",
                            style = MaterialTheme.typography.bodySmall,
                            color = WarmTextPrimary
                        )
                    }
                }

                OutlinedButton(
                    onClick = onOpenReset,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = SoftSageDark
                    ),
                    modifier = Modifier.testTag("reset_quick_button")
                ) {
                    Text("Reset")
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // TODAY'S QUICK CHECK-IN
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .border(1.dp, WarmBorder, RoundedCornerShape(16.dp)),
            color = Color.White
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "TODAY'S QUICK CHECK-IN",
                    style = MaterialTheme.typography.labelLarge,
                    color = MutedGold,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Observe your current state with calm awareness. Not a diagnostic score.",
                    style = MaterialTheme.typography.bodySmall,
                    color = WarmTextMuted
                )

                Spacer(modifier = Modifier.height(16.dp))

                AccessibleRatingSelector(
                    label = "Sleep Quality",
                    currentValue = sleepRating,
                    onValueSelected = { sleepRating = it; checkInSaved = false },
                    lowLabel = "Poor",
                    highLabel = "Restful"
                )

                Spacer(modifier = Modifier.height(16.dp))

                AccessibleRatingSelector(
                    label = "Energy Level",
                    currentValue = energyRating,
                    onValueSelected = { energyRating = it; checkInSaved = false },
                    lowLabel = "Drained",
                    highLabel = "Vibrant"
                )

                Spacer(modifier = Modifier.height(16.dp))

                AccessibleRatingSelector(
                    label = "Focus & Attention",
                    currentValue = focusRating,
                    onValueSelected = { focusRating = it; checkInSaved = false },
                    lowLabel = "Scattered",
                    highLabel = "Sharp"
                )

                Spacer(modifier = Modifier.height(16.dp))

                AccessibleRatingSelector(
                    label = "Stress Load",
                    currentValue = stressRating,
                    onValueSelected = { stressRating = it; checkInSaved = false },
                    lowLabel = "Overwhelmed",
                    highLabel = "Calm & Grounded"
                )

                Spacer(modifier = Modifier.height(16.dp))

                AccessibleRatingSelector(
                    label = "Mental Clarity",
                    currentValue = clarityRating,
                    onValueSelected = { clarityRating = it; checkInSaved = false },
                    lowLabel = "Foggy",
                    highLabel = "Clear"
                )

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = {
                        onSaveCheckIn(sleepRating, energyRating, focusRating, stressRating, clarityRating)
                        checkInSaved = true
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("save_checkin_button"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (checkInSaved) SoftSageContainer else DeepNavy,
                        contentColor = if (checkInSaved) SoftSageDark else Color.White
                    )
                ) {
                    if (checkInSaved) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = null,
                            tint = SoftSageDark,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "CHECK-IN SAVED",
                            fontWeight = FontWeight.Bold,
                            color = SoftSageDark
                        )
                    } else {
                        Text(
                            text = "RECORD TODAY'S CHECK-IN",
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        MedicalDisclaimerBanner()

        Spacer(modifier = Modifier.height(16.dp))
    }
}
