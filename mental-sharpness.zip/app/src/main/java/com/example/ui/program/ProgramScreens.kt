package com.example.ui.program

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DayCompletion
import com.example.data.model.DayLesson
import com.example.ui.components.MedicalDisclaimerBanner
import com.example.ui.theme.DeepNavy
import com.example.ui.theme.DeepNavyContainer
import com.example.ui.theme.MutedGold
import com.example.ui.theme.SoftSage
import com.example.ui.theme.SoftSageContainer
import com.example.ui.theme.SoftSageDark
import com.example.ui.theme.WarmBorder
import com.example.ui.theme.WarmCard
import com.example.ui.theme.WarmTextMuted
import com.example.ui.theme.WarmTextPrimary
import com.example.ui.theme.WarmWhite

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProgramScreen(
    allLessons: List<DayLesson>,
    completions: List<DayCompletion>,
    onSelectDay: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedWeekIndex by remember { mutableIntStateOf(0) }
    val completedDaysSet = remember(completions) { completions.map { it.dayNumber }.toSet() }

    val weeks = listOf(
        "Week 1: Noise",
        "Week 2: Foundations",
        "Week 3: Focus",
        "Week 4: Habit",
        "Final Days"
    )

    val currentWeekLessons = remember(selectedWeekIndex, allLessons) {
        when (selectedWeekIndex) {
            0 -> allLessons.filter { it.dayNumber in 1..7 }
            1 -> allLessons.filter { it.dayNumber in 8..14 }
            2 -> allLessons.filter { it.dayNumber in 15..21 }
            3 -> allLessons.filter { it.dayNumber in 22..28 }
            else -> allLessons.filter { it.dayNumber in 29..30 }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(WarmWhite)
            .padding(top = 16.dp)
    ) {
        Column(modifier = Modifier.padding(horizontal = 20.dp)) {
            Text(
                text = "30-Day Reset Program",
                style = MaterialTheme.typography.displayMedium,
                color = DeepNavy
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Learn → Practice → Track → Reflect → Consistency",
                style = MaterialTheme.typography.bodyMedium,
                color = SoftSageDark
            )
            Spacer(modifier = Modifier.height(14.dp))
        }

        ScrollableTabRow(
            selectedTabIndex = selectedWeekIndex,
            containerColor = WarmWhite,
            contentColor = DeepNavy,
            edgePadding = 20.dp,
            divider = {}
        ) {
            weeks.forEachIndexed { index, title ->
                Tab(
                    selected = selectedWeekIndex == index,
                    onClick = { selectedWeekIndex = index },
                    text = {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = if (selectedWeekIndex == index) FontWeight.Bold else FontWeight.Normal,
                            color = if (selectedWeekIndex == index) DeepNavy else WarmTextMuted
                        )
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(currentWeekLessons) { lesson ->
                val isCompleted = completedDaysSet.contains(lesson.dayNumber)

                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .border(
                            width = if (isCompleted) 1.5.dp else 1.dp,
                            color = if (isCompleted) SoftSageDark.copy(alpha = 0.5f) else WarmBorder,
                            shape = RoundedCornerShape(14.dp)
                        )
                        .clickable { onSelectDay(lesson.dayNumber) }
                        .testTag("program_day_${lesson.dayNumber}"),
                    color = if (isCompleted) Color.White else WarmCard
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (isCompleted) SoftSageDark else WarmBorder
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                if (isCompleted) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = "Completed",
                                        tint = Color.White,
                                        modifier = Modifier.size(20.dp)
                                    )
                                } else {
                                    Text(
                                        text = "${lesson.dayNumber}",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = WarmTextPrimary,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(14.dp))

                            Column {
                                Text(
                                    text = "Day ${lesson.dayNumber}: ${lesson.title}",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = DeepNavy,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "${lesson.estimatedMinutes} min action • ${lesson.weekTitle}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = WarmTextMuted
                                )
                            }
                        }

                        if (isCompleted) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = SoftSageContainer
                            ) {
                                Text(
                                    text = "Done",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = SoftSageDark,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(12.dp))
                MedicalDisclaimerBanner()
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

@Composable
fun DayDetailScreen(
    lesson: DayLesson,
    completion: DayCompletion?,
    onCompleteDay: (dayNumber: Int, reflection: String) -> Unit,
    onPlayAudio: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    var reflectionText by remember(completion) { mutableStateOf(completion?.userReflection ?: "") }
    val completedSteps = remember { mutableStateListOf<Int>() }
    val isCompleted = completion != null

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(WarmWhite)
            .verticalScroll(scrollState)
            .padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        // Back Button & Week Indicator
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier.testTag("day_detail_back")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back to Program",
                    tint = DeepNavy
                )
            }
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "WEEK ${lesson.weekNumber}: ${lesson.weekTitle.uppercase()}",
                style = MaterialTheme.typography.labelLarge,
                color = MutedGold,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = "DAY ${lesson.dayNumber}",
            style = MaterialTheme.typography.labelLarge,
            color = SoftSageDark,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = lesson.title,
            style = MaterialTheme.typography.displayMedium,
            color = DeepNavy
        )

        Spacer(modifier = Modifier.height(20.dp))

        // WHY IT MATTERS
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .border(1.dp, WarmBorder, RoundedCornerShape(14.dp)),
            color = WarmCard
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = "WHY IT MATTERS",
                    style = MaterialTheme.typography.labelLarge,
                    color = SoftSageDark,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = lesson.whyItMatters,
                    style = MaterialTheme.typography.bodyLarge,
                    color = WarmTextPrimary,
                    lineHeight = 24.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // TODAY'S ACTION STEPS
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .border(1.dp, WarmBorder, RoundedCornerShape(14.dp)),
            color = Color.White
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "TODAY'S ${lesson.estimatedMinutes}-MINUTE ACTION",
                        style = MaterialTheme.typography.labelLarge,
                        color = MutedGold,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "Interactive",
                        style = MaterialTheme.typography.labelSmall,
                        color = WarmTextMuted
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                lesson.actionSteps.forEachIndexed { index, step ->
                    val isChecked = completedSteps.contains(index)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp)
                            .clickable {
                                if (isChecked) completedSteps.remove(index) else completedSteps.add(index)
                            },
                        verticalAlignment = Alignment.Top
                    ) {
                        Checkbox(
                            checked = isChecked,
                            onCheckedChange = {
                                if (isChecked) completedSteps.remove(index) else completedSteps.add(index)
                            },
                            colors = CheckboxDefaults.colors(
                                checkedColor = SoftSageDark,
                                uncheckedColor = WarmBorder
                            ),
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = step,
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (isChecked) WarmTextMuted else WarmTextPrimary,
                            lineHeight = 22.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // OPTIONAL AUDIO BUTTON
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .border(1.dp, SoftSageDark.copy(alpha = 0.2f), RoundedCornerShape(14.dp)),
            color = SoftSageContainer
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(SoftSageDark),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Play Audio Guidance",
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = lesson.audioTitle,
                            style = MaterialTheme.typography.titleMedium,
                            color = SoftSageDark,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "${lesson.audioDurationSec / 60}:00 guided ambient audio",
                            style = MaterialTheme.typography.bodySmall,
                            color = WarmTextPrimary
                        )
                    }
                }

                Button(
                    onClick = onPlayAudio,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = SoftSageDark,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Listen")
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // REFLECTION INPUT
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .border(1.dp, WarmBorder, RoundedCornerShape(14.dp)),
            color = Color.White
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = "REFLECTION",
                    style = MaterialTheme.typography.labelLarge,
                    color = MutedGold,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "\"${lesson.reflectionPrompt}\"",
                    style = MaterialTheme.typography.titleMedium,
                    color = DeepNavy,
                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                )
                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = reflectionText,
                    onValueChange = { reflectionText = it },
                    placeholder = { Text("Write your brief thoughts here...") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(120.dp)
                        .testTag("reflection_input"),
                    shape = RoundedCornerShape(10.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // COMPLETE DAY BUTTON
        Button(
            onClick = {
                onCompleteDay(lesson.dayNumber, reflectionText)
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .testTag("complete_day_button"),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = if (isCompleted) SoftSageDark else DeepNavy,
                contentColor = Color.White
            )
        ) {
            if (isCompleted) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "DAY ${lesson.dayNumber} COMPLETED",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold
                )
            } else {
                Text(
                    text = "COMPLETE DAY ${lesson.dayNumber}",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
        MedicalDisclaimerBanner()
        Spacer(modifier = Modifier.height(16.dp))
    }
}
