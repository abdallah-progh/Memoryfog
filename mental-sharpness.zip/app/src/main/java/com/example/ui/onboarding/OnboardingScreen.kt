package com.example.ui.onboarding

import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.MedicalDisclaimerBanner
import com.example.ui.theme.DeepNavy
import com.example.ui.theme.MutedGold
import com.example.ui.theme.SoftSage
import com.example.ui.theme.SoftSageContainer
import com.example.ui.theme.SoftSageDark
import com.example.ui.theme.WarmBorder
import com.example.ui.theme.WarmCard
import com.example.ui.theme.WarmTextMuted
import com.example.ui.theme.WarmTextPrimary
import com.example.ui.theme.WarmWhite

@Composable
fun OnboardingScreen(
    onFinish: (selectedGoals: Set<String>, reminderTime: String) -> Unit,
    modifier: Modifier = Modifier
) {
    var step by remember { mutableIntStateOf(1) }
    var selectedGoals by remember {
        mutableStateOf(
            setOf("Better Focus", "Less Mental Clutter", "Better Sleep Habits")
        )
    }
    var selectedTime by remember { mutableStateOf("08:30 AM") }

    val allGoals = listOf(
        "Better Focus",
        "Less Mental Clutter",
        "Better Sleep Habits",
        "Memory Habits",
        "Daily Energy",
        "Stress Management",
        "Consistency"
    )

    val reminderOptions = listOf(
        "07:00 AM",
        "08:00 AM",
        "08:30 AM",
        "09:00 AM",
        "12:30 PM",
        "06:30 PM"
    )

    Surface(
        modifier = modifier.fillMaxSize(),
        color = WarmWhite
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header progress indicators
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp, bottom = 24.dp),
                horizontalArrangement = Arrangement.Center
            ) {
                (1..6).forEach { index ->
                    Box(
                        modifier = Modifier
                            .padding(horizontal = 4.dp)
                            .height(4.dp)
                            .width(if (index == step) 28.dp else 16.dp)
                            .clip(CircleShape)
                            .background(
                                if (index <= step) SoftSageDark else WarmBorder
                            )
                    )
                }
            }

            // Step Content
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                AnimatedContent(
                    targetState = step,
                    label = "onboarding_step"
                ) { currentStep ->
                    when (currentStep) {
                        1 -> Step1Welcome()
                        2 -> Step2Foundations()
                        3 -> Step3Goals(
                            allGoals = allGoals,
                            selectedGoals = selectedGoals,
                            onToggle = { goal ->
                                selectedGoals = if (selectedGoals.contains(goal)) {
                                    if (selectedGoals.size > 1) selectedGoals - goal else selectedGoals
                                } else {
                                    selectedGoals + goal
                                }
                            }
                        )
                        4 -> Step4ReminderTime(
                            options = reminderOptions,
                            selectedTime = selectedTime,
                            onSelect = { selectedTime = it }
                        )
                        5 -> Step5Notifications()
                        6 -> Step6Start()
                    }
                }
            }

            // Bottom action buttons
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (step > 1) {
                    OutlinedButton(
                        onClick = { step -= 1 },
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = "Back",
                            color = WarmTextPrimary,
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }

                Button(
                    onClick = {
                        if (step < 6) {
                            step += 1
                        } else {
                            onFinish(selectedGoals, selectedTime)
                        }
                    },
                    modifier = Modifier
                        .weight(if (step > 1) 2f else 1f)
                        .height(52.dp)
                        .testTag("onboarding_next_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = DeepNavy,
                        contentColor = Color.White
                    )
                ) {
                    Text(
                        text = if (step == 6) "Start Day 1" else "Continue",
                        style = MaterialTheme.typography.labelLarge,
                        fontSize = 16.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun Step1Welcome() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(72.dp)
                .clip(CircleShape)
                .background(SoftSageContainer),
            contentAlignment = Alignment.Center
        ) {
            Text(text = "🌿", fontSize = 34.sp)
        }
        Spacer(modifier = Modifier.height(24.dp))
        Text(
            text = "MENTAL SHARPNESS",
            style = MaterialTheme.typography.labelLarge,
            color = MutedGold,
            letterSpacing = 2.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "30-Day Reset",
            style = MaterialTheme.typography.displayLarge,
            color = DeepNavy,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "\"Small daily actions. A clearer routine.\"",
            style = MaterialTheme.typography.titleMedium,
            color = SoftSageDark,
            fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(20.dp))
        Text(
            text = "An educational wellness companion for adults 40+ designed to quiet everyday noise and restore calm daily focus.",
            style = MaterialTheme.typography.bodyLarge,
            color = WarmTextMuted,
            textAlign = TextAlign.Center,
            lineHeight = 24.sp
        )
        Spacer(modifier = Modifier.height(28.dp))
        MedicalDisclaimerBanner()
    }
}

@Composable
private fun Step2Foundations() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.Start,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "Practical Daily Habits",
            style = MaterialTheme.typography.displaySmall,
            color = DeepNavy
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "Designed specifically for adults 40–65 to build sustainable routines around six vital pillars:",
            style = MaterialTheme.typography.bodyLarge,
            color = WarmTextMuted
        )
        Spacer(modifier = Modifier.height(20.dp))

        val pillars = listOf(
            "Deep Focus & Single-Tasking" to "Protecting attention from digital fragmentation.",
            "Restorative Sleep" to "Calm transitions that support natural overnight recovery.",
            "Mental Organization" to "Offloading working memory to stop cognitive overwhelm.",
            "Everyday Memory Retrieval" to "Strengthening active recall in daily routines.",
            "Light & Daily Movement" to "Circadian alignment and energy circulation.",
            "Stress & Reset Awareness" to "5-minute circuit breakers to restart whenever needed."
        )

        pillars.forEach { (title, desc) ->
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 5.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .border(1.dp, WarmBorder, RoundedCornerShape(10.dp)),
                color = WarmCard
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(SoftSageDark),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.titleSmall,
                            color = WarmTextPrimary,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = desc,
                            style = MaterialTheme.typography.bodySmall,
                            color = WarmTextMuted
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun Step3Goals(
    allGoals: List<String>,
    selectedGoals: Set<String>,
    onToggle: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.Start
    ) {
        Text(
            text = "What would you like to work on?",
            style = MaterialTheme.typography.displaySmall,
            color = DeepNavy
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "Select all areas where you would appreciate more clarity and steady routines:",
            style = MaterialTheme.typography.bodyMedium,
            color = WarmTextMuted
        )
        Spacer(modifier = Modifier.height(20.dp))

        allGoals.forEach { goal ->
            val isSelected = selectedGoals.contains(goal)
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 5.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .border(
                        width = if (isSelected) 1.5.dp else 1.dp,
                        color = if (isSelected) SoftSageDark else WarmBorder,
                        shape = RoundedCornerShape(12.dp)
                    )
                    .clickable { onToggle(goal) },
                color = if (isSelected) SoftSageContainer else WarmCard
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = goal,
                        style = MaterialTheme.typography.titleMedium,
                        color = if (isSelected) SoftSageDark else WarmTextPrimary,
                        fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal
                    )
                    Checkbox(
                        checked = isSelected,
                        onCheckedChange = { onToggle(goal) },
                        colors = CheckboxDefaults.colors(
                            checkedColor = SoftSageDark,
                            uncheckedColor = WarmBorder
                        )
                    )
                }
            }
        }
    }
}

@Composable
private fun Step4ReminderTime(
    options: List<String>,
    selectedTime: String,
    onSelect: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.Start
    ) {
        Text(
            text = "Preferred Reminder Time",
            style = MaterialTheme.typography.displaySmall,
            color = DeepNavy
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "When would you like your unhurried daily prompt? (Takes only 5–10 minutes)",
            style = MaterialTheme.typography.bodyMedium,
            color = WarmTextMuted
        )
        Spacer(modifier = Modifier.height(24.dp))

        options.forEach { time ->
            val isSelected = time == selectedTime
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .border(
                        width = if (isSelected) 2.dp else 1.dp,
                        color = if (isSelected) SoftSageDark else WarmBorder,
                        shape = RoundedCornerShape(12.dp)
                    )
                    .clickable { onSelect(time) },
                color = if (isSelected) SoftSageContainer else WarmCard
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = time,
                        style = MaterialTheme.typography.titleLarge,
                        color = if (isSelected) SoftSageDark else WarmTextPrimary,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                    )
                    if (isSelected) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Selected",
                            tint = SoftSageDark,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun Step5Notifications() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(68.dp)
                .clip(CircleShape)
                .background(MutedGold.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Notifications,
                contentDescription = "Notifications",
                tint = MutedGold,
                modifier = Modifier.size(34.dp)
            )
        }
        Spacer(modifier = Modifier.height(20.dp))
        Text(
            text = "Calm, Respectful Reminders",
            style = MaterialTheme.typography.displaySmall,
            color = DeepNavy,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = "We never use manipulative, urgent, or spam notifications. A gentle once-daily cue reminds you to take your 5-minute pause and build habit consistency.",
            style = MaterialTheme.typography.bodyLarge,
            color = WarmTextMuted,
            textAlign = TextAlign.Center,
            lineHeight = 24.sp
        )
        Spacer(modifier = Modifier.height(20.dp))
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp)),
            color = WarmCard
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Example notification:",
                    style = MaterialTheme.typography.labelSmall,
                    color = WarmTextMuted
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "\"Your 5-minute Mental Reset is ready. Clear the noise and refocus.\"",
                    style = MaterialTheme.typography.bodyMedium,
                    color = WarmTextPrimary,
                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                )
            }
        }
    }
}

@Composable
private fun Step6Start() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "Your 30-Day Reset",
            style = MaterialTheme.typography.headlineLarge,
            color = MutedGold,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "Starts Today.",
            style = MaterialTheme.typography.displayLarge,
            color = DeepNavy,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "Day 1 will take only 5 minutes. You'll complete an initial baseline snapshot and write down your primary focus.",
            style = MaterialTheme.typography.bodyLarge,
            color = WarmTextMuted,
            textAlign = TextAlign.Center,
            lineHeight = 24.sp
        )
        Spacer(modifier = Modifier.height(24.dp))
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .border(1.dp, WarmBorder, RoundedCornerShape(14.dp)),
            color = WarmCard
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Core Rule For Success",
                    style = MaterialTheme.typography.labelLarge,
                    color = SoftSageDark,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Do not aim for perfection. If you miss a day, simply resume without guilt. Consistency over 30 days is about showing up.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = WarmTextPrimary,
                    lineHeight = 22.sp
                )
            }
        }
    }
}
