package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.AudioPlayerState
import com.example.audio.MentalSharpnessAudioEngine
import com.example.data.local.AppDatabase
import com.example.data.model.AudioSession
import com.example.data.model.BrainFogEntry
import com.example.data.model.DailyCheckIn
import com.example.data.model.DayCompletion
import com.example.data.model.DayLesson
import com.example.data.model.UserNote
import com.example.data.model.UserSettings
import com.example.data.repository.ProgramRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class AppNavDestination {
    HOME,
    PROGRAM,
    TRACK,
    RESET,
    PROFILE,
    DAY_DETAIL,
    ADMIN
}

data class ProgressSummary(
    val currentDay: Int = 1,
    val completedCount: Int = 0,
    val currentStreak: Int = 0,
    val longestStreak: Int = 0,
    val isFinishedDay30: Boolean = false
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application)
    val repository = ProgramRepository(database)
    val audioEngine = MentalSharpnessAudioEngine(application)

    private val _currentTab = MutableStateFlow(AppNavDestination.HOME)
    val currentTab: StateFlow<AppNavDestination> = _currentTab.asStateFlow()

    private val _selectedDayNumber = MutableStateFlow(1)
    val selectedDayNumber: StateFlow<Int> = _selectedDayNumber.asStateFlow()

    private val _settings = MutableStateFlow(UserSettings())
    val settings: StateFlow<UserSettings> = _settings.asStateFlow()

    private val _adminNotificationStatus = MutableStateFlow<String?>(null)
    val adminNotificationStatus: StateFlow<String?> = _adminNotificationStatus.asStateFlow()

    val audioState: StateFlow<AudioPlayerState> = audioEngine.state

    val allCompletions: StateFlow<List<DayCompletion>> = repository.allCompletions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allCheckIns: StateFlow<List<DailyCheckIn>> = repository.allCheckIns
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allBrainFogEntries: StateFlow<List<BrainFogEntry>> = repository.allBrainFogEntries
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allNotes: StateFlow<List<UserNote>> = repository.allNotes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val progressSummary: StateFlow<ProgressSummary> = allCompletions.combine(allCheckIns) { completions, checkins ->
        val completedDaysSet = completions.map { it.dayNumber }.toSet()
        val count = completions.size
        val nextDay = ((1..30).firstOrNull { it !in completedDaysSet } ?: 30)

        // Calculate continuous streak based on completions and check-ins
        val streak = if (count > 0) count.coerceAtLeast(1) else (if (checkins.isNotEmpty()) 1 else 0)
        val longest = streak.coerceAtLeast(completions.size)

        ProgressSummary(
            currentDay = nextDay,
            completedCount = count,
            currentStreak = streak,
            longestStreak = longest,
            isFinishedDay30 = completedDaysSet.contains(30)
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ProgressSummary())

    fun navigateTo(destination: AppNavDestination) {
        _currentTab.value = destination
    }

    fun openDayDetail(dayNumber: Int) {
        _selectedDayNumber.value = dayNumber
        _currentTab.value = AppNavDestination.DAY_DETAIL
    }

    fun completeCurrentDay(dayNumber: Int, reflection: String) {
        viewModelScope.launch {
            repository.saveDayCompletion(dayNumber, reflection)
            audioEngine.playChime()
            if (dayNumber < 30) {
                _selectedDayNumber.value = dayNumber + 1
            }
        }
    }

    fun saveQuickCheckIn(sleep: Int, energy: Int, focus: Int, stress: Int, clarity: Int, notes: String = "") {
        viewModelScope.launch {
            val dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            repository.saveCheckIn(
                DailyCheckIn(
                    dateString = dateStr,
                    sleepQuality = sleep,
                    energy = energy,
                    focus = focus,
                    stress = stress,
                    mentalClarity = clarity,
                    notes = notes
                )
            )
            audioEngine.playChime()
        }
    }

    fun saveBrainFogLog(
        sleep: Int,
        energy: Int,
        stress: Int,
        focus: Int,
        clarity: Int,
        activity: String,
        hydration: String,
        workload: String,
        distractions: String,
        freeNotes: String
    ) {
        viewModelScope.launch {
            val now = Date()
            val dateDisplay = SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(now)
            val timeDisplay = SimpleDateFormat("h:mm a", Locale.getDefault()).format(now)

            repository.saveBrainFogEntry(
                BrainFogEntry(
                    dateDisplay = dateDisplay,
                    timeDisplay = timeDisplay,
                    sleepRating = sleep,
                    energyRating = energy,
                    stressRating = stress,
                    focusRating = focus,
                    clarityRating = clarity,
                    recentActivity = activity,
                    hydrationMeals = hydration,
                    workload = workload,
                    distractions = distractions,
                    freeNotes = freeNotes
                )
            )
            audioEngine.playChime()
        }
    }

    fun deleteBrainFogLog(entry: BrainFogEntry) {
        viewModelScope.launch {
            repository.deleteBrainFogEntry(entry)
        }
    }

    fun savePersonalNote(title: String, content: String, category: String = "General") {
        viewModelScope.launch {
            repository.saveNote(
                UserNote(
                    title = title,
                    content = content,
                    category = category
                )
            )
            audioEngine.playChime()
        }
    }

    fun deletePersonalNote(note: UserNote) {
        viewModelScope.launch {
            repository.deleteNote(note)
        }
    }

    fun updateName(name: String) {
        _settings.value = _settings.value.copy(userName = name)
    }

    fun updateReminderTime(time: String) {
        _settings.value = _settings.value.copy(reminderTime = time)
    }

    fun toggleNotifications(enabled: Boolean) {
        _settings.value = _settings.value.copy(notificationsEnabled = enabled)
    }

    fun toggleSoundEffects(enabled: Boolean) {
        _settings.value = _settings.value.copy(soundEffectsEnabled = enabled)
        audioEngine.toggleSoundEffects(enabled)
    }

    fun toggleBackgroundAudio(enabled: Boolean) {
        _settings.value = _settings.value.copy(backgroundAudioEnabled = enabled)
        audioEngine.toggleBackgroundAudio(enabled)
    }

    fun toggleVoice(enabled: Boolean) {
        _settings.value = _settings.value.copy(voiceGuidanceEnabled = enabled)
        audioEngine.toggleVoice(enabled)
    }

    fun completeOnboarding(selectedGoals: Set<String>, reminderTime: String) {
        _settings.value = _settings.value.copy(
            isOnboarded = true,
            selectedGoals = selectedGoals,
            reminderTime = reminderTime
        )
    }

    fun updateAnchorHabits(habits: List<String>) {
        _settings.value = _settings.value.copy(personalAnchorHabits = habits)
    }

    fun redeemAccessCode(code: String): Boolean {
        val trimmed = code.trim().uppercase()
        // Allow common valid redemption codes or any purchase ID
        val isValid = trimmed.isNotEmpty() && (
            trimmed.contains("SHARP") ||
            trimmed.contains("RESET") ||
            trimmed.contains("GUMROAD") ||
            trimmed.contains("VIP") ||
            trimmed.contains("BONUS") ||
            trimmed.length >= 5
        )

        if (isValid) {
            _settings.value = _settings.value.copy(
                isAccessUnlocked = true,
                accessCodeUsed = trimmed
            )
            audioEngine.playChime()
            return true
        }
        return false
    }

    fun resetAllProgress() {
        viewModelScope.launch {
            repository.resetAllProgress()
            _selectedDayNumber.value = 1
            _currentTab.value = AppNavDestination.HOME
        }
    }

    fun playAudioSession(session: AudioSession) {
        audioEngine.playSession(session)
    }

    fun pauseAudio() {
        audioEngine.pause()
    }

    fun resumeAudio() {
        audioEngine.resume()
    }

    fun stopAudio() {
        audioEngine.stop()
    }

    fun seekAudio(sec: Int) {
        audioEngine.seekTo(sec)
    }

    fun setAudioVolume(vol: Float) {
        audioEngine.setVolume(vol)
    }

    // Admin Campaign Simulator
    fun sendAdminNotification(title: String, message: String, targetAudience: String) {
        _adminNotificationStatus.value = "Notification sent to $targetAudience: \"$title\""
        audioEngine.playChime()
    }

    fun clearAdminNotificationStatus() {
        _adminNotificationStatus.value = null
    }

    override fun onCleared() {
        super.onCleared()
        audioEngine.stop()
    }
}
