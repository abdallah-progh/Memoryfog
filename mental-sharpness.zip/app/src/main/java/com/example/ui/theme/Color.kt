package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Editorial Palette
val DeepNavy = Color(0xFF0F1B29)
val DeepNavySurface = Color(0xFF152438)
val DeepNavyContainer = Color(0xFF1E324D)
val DeepNavyLight = Color(0xFF284163)

// Warm Backgrounds & Neutrals
val WarmWhite = Color(0xFFFAF8F5)
val WarmCard = Color(0xFFF3EFEA)
val WarmBorder = Color(0xFFE4DFD5)
val WarmTextMuted = Color(0xFF6B7280)
val WarmTextPrimary = Color(0xFF1B242F)

// Soft Sage Green (Calm / Action / Balance)
val SoftSage = Color(0xFF4A6B5D)
val SoftSageDark = Color(0xFF365045)
val SoftSageLight = Color(0xFFD4E1DA)
val SoftSageContainer = Color(0xFFE8EFEA)

// Muted Gold (Milestones / Premium Accent / Focus)
val MutedGold = Color(0xFFC09838)
val MutedGoldDark = Color(0xFF9E7B26)
val MutedGoldLight = Color(0xFFF5EAC9)

// Accent / Status
val SoftCoral = Color(0xFFD96B58)
val CalmSky = Color(0xFF5B82A6)
