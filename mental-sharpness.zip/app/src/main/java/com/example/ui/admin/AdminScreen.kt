package com.example.ui.admin

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.ProgressSummary
import com.example.ui.theme.DeepNavy
import com.example.ui.theme.MutedGold
import com.example.ui.theme.SoftSage
import com.example.ui.theme.SoftSageContainer
import com.example.ui.theme.SoftSageDark
import com.example.ui.theme.WarmBorder
import com.example.ui.theme.WarmCard
import com.example.ui.theme.WarmTextMuted
import com.example.ui.theme.WarmTextPrimary
import com.example.ui.theme.WarmWhite

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminScreen(
    progress: ProgressSummary,
    notificationStatus: String?,
    onSendNotification: (title: String, message: String, audience: String) -> Unit,
    onClearNotificationStatus: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    var title by remember { mutableStateOf("Your 5-Minute Mental Reset is Ready") }
    var message by remember { mutableStateOf("Clear the noise, take a slow breath, and reclaim calm focus today.") }
    var audienceExpanded by remember { mutableStateOf(false) }
    var selectedAudience by remember { mutableStateOf("All Active 30-Day Participants") }

    val audiences = listOf(
        "All Active 30-Day Participants",
        "Day 1–7 Beginners",
        "Week 3 Focus Cohort",
        "Evening Wind-Down Segment",
        "Lapsed Participants (2+ days inactive)"
    )

    val templates = listOf(
        "Focus Cue" to ("Your 5-Minute Mental Reset is Ready" to "Clear the noise, take a slow breath, and reclaim calm focus today."),
        "Sleep Wind-Down" to ("Evening Wind-Down" to "The day's tasks are done. Dim your lights and step off the mental treadmill."),
        "Morning Sunlight" to ("Morning Anchor Alert" to "Step outside for 7 minutes of natural daylight to set your focus clock.")
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(WarmWhite)
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack, modifier = Modifier.testTag("admin_back_button")) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back to App",
                        tint = DeepNavy
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "ADMIN & CAMPAIGNS",
                        style = MaterialTheme.typography.labelLarge,
                        color = MutedGold,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "Notification Hub & Analytics",
                        style = MaterialTheme.typography.headlineSmall,
                        color = DeepNavy,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Live status banner
        if (notificationStatus != null) {
            item {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp)),
                    color = SoftSageContainer
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = SoftSageDark,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = notificationStatus,
                                style = MaterialTheme.typography.bodySmall,
                                color = SoftSageDark,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        IconButton(
                            onClick = onClearNotificationStatus,
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Dismiss",
                                tint = SoftSageDark
                            )
                        }
                    }
                }
            }
        }

        // Real-time metrics overview
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .border(1.dp, WarmBorder, RoundedCornerShape(14.dp)),
                color = Color.White
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Engagement Overview",
                        style = MaterialTheme.typography.titleMedium,
                        color = DeepNavy,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        MetricCard(label = "Delivery Rate", value = "98.7%", color = SoftSageDark)
                        MetricCard(label = "Avg Open Rate", value = "74.2%", color = DeepNavy)
                        MetricCard(label = "Day 30 Grad", value = "68.5%", color = MutedGold)
                    }
                }
            }
        }

        // Notification composer card
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .border(1.dp, WarmBorder, RoundedCornerShape(14.dp)),
                color = Color.White
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Campaign,
                            contentDescription = null,
                            tint = SoftSageDark,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Broadcast Push Notification",
                            style = MaterialTheme.typography.titleMedium,
                            color = DeepNavy,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "Target Audience Segment:",
                        style = MaterialTheme.typography.labelSmall,
                        color = WarmTextMuted
                    )
                    Spacer(modifier = Modifier.height(4.dp))

                    ExposedDropdownMenuBox(
                        expanded = audienceExpanded,
                        onExpandedChange = { audienceExpanded = !audienceExpanded }
                    ) {
                        TextField(
                            value = selectedAudience,
                            onValueChange = {},
                            readOnly = true,
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = audienceExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                        )
                        ExposedDropdownMenu(
                            expanded = audienceExpanded,
                            onDismissRequest = { audienceExpanded = false }
                        ) {
                            audiences.forEach { aud ->
                                DropdownMenuItem(
                                    text = { Text(aud) },
                                    onClick = {
                                        selectedAudience = aud
                                        audienceExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "Quick Campaign Templates:",
                        style = MaterialTheme.typography.labelSmall,
                        color = WarmTextMuted
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        templates.forEach { (name, pair) ->
                            Surface(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable {
                                        title = pair.first
                                        message = pair.second
                                    },
                                color = WarmCard
                            ) {
                                Text(
                                    text = name,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = DeepNavy,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("Notification Title") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = message,
                        onValueChange = { message = it },
                        label = { Text("Message Body") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(100.dp)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            onSendNotification(title, message, selectedAudience)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("admin_send_broadcast_button"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = DeepNavy,
                            contentColor = Color.White
                        )
                    ) {
                        Icon(imageVector = Icons.Default.Send, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Send Broadcast Now", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Recent broadcast history
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .border(1.dp, WarmBorder, RoundedCornerShape(14.dp)),
                color = Color.White
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Recent Campaign Dispatches",
                        style = MaterialTheme.typography.titleMedium,
                        color = DeepNavy,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    val history = listOf(
                        "Day 1 Baseline Prompt" to "Sent to 1,420 users • 82% opened",
                        "Week 2 Sleep Review Prompt" to "Sent to 1,180 users • 77% opened",
                        "Midday 5-Minute Reset Cue" to "Sent to 960 users • 69% opened"
                    )

                    history.forEach { (hTitle, hMeta) ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp)
                        ) {
                            Text(
                                text = hTitle,
                                style = MaterialTheme.typography.bodyMedium,
                                color = WarmTextPrimary,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = hMeta,
                                style = MaterialTheme.typography.labelSmall,
                                color = WarmTextMuted
                            )
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun MetricCard(
    label: String,
    value: String,
    color: Color
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = WarmCard,
        modifier = Modifier.width(96.dp)
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge,
                color = color,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = WarmTextMuted,
                fontSize = 10.sp
            )
        }
    }
}
