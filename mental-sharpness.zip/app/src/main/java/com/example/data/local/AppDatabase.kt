package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.BrainFogEntry
import com.example.data.model.DailyCheckIn
import com.example.data.model.DayCompletion
import com.example.data.model.UserNote

@Database(
    entities = [
        DayCompletion::class,
        DailyCheckIn::class,
        BrainFogEntry::class,
        UserNote::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dayCompletionDao(): DayCompletionDao
    abstract fun dailyCheckInDao(): DailyCheckInDao
    abstract fun brainFogDao(): BrainFogDao
    abstract fun userNoteDao(): UserNoteDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "mental_sharpness_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
