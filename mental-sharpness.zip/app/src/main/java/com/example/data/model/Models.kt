package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class AudioCategory(val displayName: String) {
    FOCUS("Focus"),
    RESET("Reset"),
    SLEEP("Sleep"),
    BREATHING("Breathing"),
    MINDFUL_PAUSE("Mindful Pause")
}

data class DayLesson(
    val dayNumber: Int,
    val weekNumber: Int,
    val weekTitle: String,
    val title: String,
    val whyItMatters: String,
    val actionSteps: List<String>,
    val reflectionPrompt: String,
    val estimatedMinutes: Int = 10,
    val audioTitle: String = "Daily Reset Guidance",
    val audioDurationSec: Int = 300
)

@Entity(tableName = "day_completions")
data class DayCompletion(
    @PrimaryKey val dayNumber: Int,
    val completedAt: Long = System.currentTimeMillis(),
    val userReflection: String = "",
    val isFavorite: Boolean = false
)

@Entity(tableName = "daily_checkins")
data class DailyCheckIn(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dateString: String,
    val timestamp: Long = System.currentTimeMillis(),
    val sleepQuality: Int = 3,
    val energy: Int = 3,
    val focus: Int = 3,
    val stress: Int = 3,
    val mentalClarity: Int = 3,
    val notes: String = ""
)

@Entity(tableName = "brain_fog_entries")
data class BrainFogEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val dateDisplay: String,
    val timeDisplay: String,
    val sleepRating: Int = 3,
    val energyRating: Int = 3,
    val stressRating: Int = 3,
    val focusRating: Int = 3,
    val clarityRating: Int = 3,
    val recentActivity: String = "",
    val hydrationMeals: String = "",
    val workload: String = "Moderate",
    val distractions: String = "",
    val freeNotes: String = ""
)

@Entity(tableName = "user_notes")
data class UserNote(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val category: String = "General"
)

data class AudioSession(
    val id: String,
    val title: String,
    val subtitle: String,
    val category: AudioCategory,
    val durationSec: Int,
    val frequencyHz: Double,
    val guidanceScript: String
)

data class UserSettings(
    val userName: String = "Adult 40+",
    val reminderTime: String = "08:30 AM",
    val notificationsEnabled: Boolean = true,
    val soundEffectsEnabled: Boolean = true,
    val backgroundAudioEnabled: Boolean = true,
    val voiceGuidanceEnabled: Boolean = true,
    val isAccessUnlocked: Boolean = true,
    val accessCodeUsed: String = "GUMROAD-BONUS",
    val isOnboarded: Boolean = false,
    val selectedGoals: Set<String> = setOf("Better Focus", "Less Mental Clutter", "Better Sleep Habits"),
    val personalAnchorHabits: List<String> = listOf(
        "10-minute morning light & walk",
        "Single-tasking 25-minute focus block",
        "Screen-free transition 45 mins before sleep"
    )
)
