package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.model.AudioCategory
import com.example.data.model.AudioSession
import com.example.data.model.BrainFogEntry
import com.example.data.model.DailyCheckIn
import com.example.data.model.DayCompletion
import com.example.data.model.DayLesson
import com.example.data.model.UserNote
import kotlinx.coroutines.flow.Flow

class ProgramRepository(private val database: AppDatabase) {

    val allCompletions: Flow<List<DayCompletion>> = database.dayCompletionDao().getAllCompletions()
    val allCheckIns: Flow<List<DailyCheckIn>> = database.dailyCheckInDao().getAllCheckIns()
    val allBrainFogEntries: Flow<List<BrainFogEntry>> = database.brainFogDao().getAllEntries()
    val allNotes: Flow<List<UserNote>> = database.userNoteDao().getAllNotes()

    suspend fun saveDayCompletion(dayNumber: Int, reflection: String) {
        database.dayCompletionDao().insertCompletion(
            DayCompletion(
                dayNumber = dayNumber,
                completedAt = System.currentTimeMillis(),
                userReflection = reflection
            )
        )
    }

    suspend fun saveCheckIn(checkIn: DailyCheckIn) {
        database.dailyCheckInDao().insertCheckIn(checkIn)
    }

    suspend fun saveBrainFogEntry(entry: BrainFogEntry) {
        database.brainFogDao().insertEntry(entry)
    }

    suspend fun deleteBrainFogEntry(entry: BrainFogEntry) {
        database.brainFogDao().deleteEntry(entry)
    }

    suspend fun saveNote(note: UserNote) {
        database.userNoteDao().insertNote(note)
    }

    suspend fun deleteNote(note: UserNote) {
        database.userNoteDao().deleteNote(note)
    }

    suspend fun resetAllProgress() {
        database.dayCompletionDao().clearAll()
        database.dailyCheckInDao().clearAll()
        database.brainFogDao().clearAll()
        database.userNoteDao().clearAll()
    }

    fun getDayLesson(dayNumber: Int): DayLesson {
        return allLessons.getOrNull(dayNumber - 1) ?: allLessons.first()
    }

    val audioSessions: List<AudioSession> = listOf(
        AudioSession(
            id = "audio_reset_5",
            title = "5-Minute Mental Reset",
            subtitle = "Clear mental clutter and regain steady baseline presence",
            category = AudioCategory.RESET,
            durationSec = 300,
            frequencyHz = 432.0,
            guidanceScript = "Take a slow, generous breath in through your nose... pause softly at the top... and release completely. Release any tension from your brow and shoulders. What is pulling your attention right now? Acknowledge it gently without urgency. Now choose ONE small action to focus on next."
        ),
        AudioSession(
            id = "audio_focus_prep",
            title = "5-Minute Focus Preparation",
            subtitle = "Prime your brain for a single uninterrupted deep work block",
            category = AudioCategory.FOCUS,
            durationSec = 300,
            frequencyHz = 528.0,
            guidanceScript = "Set aside all browser tabs and secondary notifications. Write the single goal of your session on paper. Take three grounding breaths. Your only mission for the next 25 minutes is this singular task."
        ),
        AudioSession(
            id = "audio_breathing_478",
            title = "Box & Calming Breath",
            subtitle = "Downregulate sympathetic nervous tension in 3 minutes",
            category = AudioCategory.BREATHING,
            durationSec = 180,
            frequencyHz = 256.0,
            guidanceScript = "Breathe in gently for 4 counts: 1, 2, 3, 4. Hold comfortably: 1, 2, 3, 4. Release smoothly through parted lips: 1, 2, 3, 4, 5, 6. Notice the immediate drop in physical strain."
        ),
        AudioSession(
            id = "audio_evening_wind",
            title = "10-Minute Wind-Down",
            subtitle = "Transition cleanly from day duties into deep restorative sleep",
            category = AudioCategory.SLEEP,
            durationSec = 600,
            frequencyHz = 216.0,
            guidanceScript = "The work of today is concluded. Whatever remains undone will wait safely until tomorrow. Dim your lighting. Notice the weight of your body resting supported. Let your mind step off the treadmill."
        ),
        AudioSession(
            id = "audio_morning_ground",
            title = "Morning Grounding & Anchor",
            subtitle = "Set an intentional, unhurried tone before screens intrude",
            category = AudioCategory.MINDFUL_PAUSE,
            durationSec = 240,
            frequencyHz = 396.0,
            guidanceScript = "Before checking messages or incoming demands, claim these four minutes for yourself. Place your feet flat on the floor. Clarify the one priority that would make today worthwhile."
        ),
        AudioSession(
            id = "audio_quick_reset_2",
            title = "2-Minute Rapid Reset",
            subtitle = "A fast mental circuit breaker between meetings or tasks",
            category = AudioCategory.RESET,
            durationSec = 120,
            frequencyHz = 432.0,
            guidanceScript = "Close your eyes or soften your gaze. Exhale all accumulated hurry. Ask yourself: 'What actually needs doing in the next ten minutes?' Keep it simple."
        )
    )

    val allLessons: List<DayLesson> = listOf(
        // WEEK 1: CLEAR THE NOISE
        DayLesson(
            dayNumber = 1,
            weekNumber = 1,
            weekTitle = "Clear The Noise",
            title = "Baseline Check",
            whyItMatters = "You cannot optimize what you do not observe. Taking an honest, non-judgmental snapshot of your current cognitive load is the first step toward reclaiming mental space.",
            actionSteps = listOf(
                "Complete today's 1-minute quick check-in below to record your current sleep, energy, and focus baselines.",
                "Take a notepad and write down the top 3 persistent thoughts or concerns occupying your mind right now.",
                "Remind yourself: this program is about sustainable daily consistency, not perfection."
            ),
            reflectionPrompt = "What is the primary cognitive drain you notice most frequently throughout your week?",
            estimatedMinutes = 5
        ),
        DayLesson(
            dayNumber = 2,
            weekNumber = 1,
            weekTitle = "Clear The Noise",
            title = "Sleep Snapshot",
            whyItMatters = "Cognitive clarity after 40 is deeply coupled to restorative sleep. Understanding how your sleep environment influences morning fog helps you make tiny, high-yield adjustments.",
            actionSteps = listOf(
                "Notice your wake time and bedroom temperature this morning.",
                "Commit to keeping phone charging at least arm's length away from your bed tonight.",
                "Note down your morning mental clarity score."
            ),
            reflectionPrompt = "What single bedtime habit currently disrupts a peaceful transition to sleep?",
            estimatedMinutes = 8
        ),
        DayLesson(
            dayNumber = 3,
            weekNumber = 1,
            weekTitle = "Clear The Noise",
            title = "Reduce One Distraction",
            whyItMatters = "Continuous partial attention drains dopamine and executive reserves. Eliminating just one persistent digital ping saves measurable cognitive energy.",
            actionSteps = listOf(
                "Identify the app or notification that most frequently breaks your flow (e.g. breaking news or social feeds).",
                "Turn off non-essential notifications for that specific app for the next 24 hours.",
                "Notice the subtle urge to check it throughout your afternoon."
            ),
            reflectionPrompt = "Which notification did you mute, and how did your attention feel as a result?",
            estimatedMinutes = 5
        ),
        DayLesson(
            dayNumber = 4,
            weekNumber = 1,
            weekTitle = "Clear The Noise",
            title = "Morning Light & Movement",
            whyItMatters = "Natural morning sunlight sets your suprachiasmatic nucleus (circadian master clock), signaling cortisol production and clearing adenosine fog naturally.",
            actionSteps = listOf(
                "Step outside within 60 minutes of waking for 7–10 minutes of natural daylight.",
                "Engage in gentle movement—a relaxed stroll, neck and shoulder stretches, or deep breathing.",
                "Avoid looking at emails or headlines during these outdoor minutes."
            ),
            reflectionPrompt = "How did stepping outside before checking incoming alerts affect your mental alertness?",
            estimatedMinutes = 10
        ),
        DayLesson(
            dayNumber = 5,
            weekNumber = 1,
            weekTitle = "Clear The Noise",
            title = "Mental Clutter Dump",
            whyItMatters = "Working memory can only juggle 4 to 5 items comfortably. Unfinished tasks generate subconscious cognitive friction (the Zeigarnik effect) until recorded externally.",
            actionSteps = listOf(
                "Grab a blank sheet of paper and set a timer for 6 minutes.",
                "Write down every single lingering to-do, errand, or unreturned message without formatting.",
                "Circle just ONE item to address today. File the rest out of view."
            ),
            reflectionPrompt = "How does your mental head-space feel once the thoughts are transferred to physical paper?",
            estimatedMinutes = 8
        ),
        DayLesson(
            dayNumber = 6,
            weekNumber = 1,
            weekTitle = "Clear The Noise",
            title = "One-Task Challenge",
            whyItMatters = "Multitasking is a myth; the brain rapidly switches tasks, incurring high metabolic costs and increasing errors. Single-tasking rebuilds sustained concentration.",
            actionSteps = listOf(
                "Select one meaningful task (drafting a document, reading a chapter, or organizing a desk).",
                "Close all other tabs and put your phone in another room or face-down on silent.",
                "Work on solely this task for 20 uninterrupted minutes."
            ),
            reflectionPrompt = "How many times did your mind tempt you to check something unrelated during the 20 minutes?",
            estimatedMinutes = 20
        ),
        DayLesson(
            dayNumber = 7,
            weekNumber = 1,
            weekTitle = "Clear The Noise",
            title = "Weekly Review: Week 1",
            whyItMatters = "Pausing at weekly milestones reinforces positive neural reinforcement and allows you to calibrate what worked without self-criticism.",
            actionSteps = listOf(
                "Look back at your 7 days of check-ins in the Track tab.",
                "Identify the one day you experienced the cleanest mental clarity and note what accompanied it.",
                "Celebrate completing Week 1 of your 30-Day Reset."
            ),
            reflectionPrompt = "What was the most valuable habit or observation you made during your first week?",
            estimatedMinutes = 10
        ),

        // WEEK 2: BUILD BETTER FOUNDATIONS
        DayLesson(
            dayNumber = 8,
            weekNumber = 2,
            weekTitle = "Build Better Foundations",
            title = "Review Your Sleep Pattern",
            whyItMatters = "Quality sleep allows the brain's glymphatic system to wash out metabolic debris accumulated throughout waking hours.",
            actionSteps = listOf(
                "Check your average sleep rating from Week 1.",
                "Ensure your bedroom is dark, cool (around 65°F / 18°C), and quiet tonight.",
                "Try stopping screen exposure 30 minutes before your planned bedtime."
            ),
            reflectionPrompt = "What environmental tweak made your resting space noticeably more inviting tonight?",
            estimatedMinutes = 10
        ),
        DayLesson(
            dayNumber = 9,
            weekNumber = 2,
            weekTitle = "Build Better Foundations",
            title = "Create a Simple Morning Anchor",
            whyItMatters = "An anchor habit eliminates morning decision fatigue and sets a grounded emotional tone before external demands begin.",
            actionSteps = listOf(
                "Pick one effortless anchor: a tall glass of water with lemon, 5 slow breaths, or opening blinds.",
                "Pair this anchor with an existing habit (e.g. right as your coffee brews).",
                "Practice the anchor slowly with full physical presence."
            ),
            reflectionPrompt = "What simple morning anchor did you choose to ground your start today?",
            estimatedMinutes = 5
        ),
        DayLesson(
            dayNumber = 10,
            weekNumber = 2,
            weekTitle = "Build Better Foundations",
            title = "Hydration & Meal Awareness",
            whyItMatters = "Even mild dehydration of 1–2% measurably impairs memory and concentration in mature adults.",
            actionSteps = listOf(
                "Drink an extra glass of water mid-morning and mid-afternoon.",
                "Notice if afternoon brain fog correlates with heavy refined carbohydrate lunches.",
                "Include a handful of nuts, seeds, or leafy greens in your daily meals."
            ),
            reflectionPrompt = "Did regular water intake throughout the morning soften the usual 3 PM slump?",
            estimatedMinutes = 5
        ),
        DayLesson(
            dayNumber = 11,
            weekNumber = 2,
            weekTitle = "Build Better Foundations",
            title = "Movement Break",
            whyItMatters = "Cardiovascular movement increases BDNF (Brain-Derived Neurotrophic Factor), encouraging synaptic plasticity and focus.",
            actionSteps = listOf(
                "Set an hourly reminder to stand up, stretch arms, and roll your shoulders.",
                "Take a 10–15 minute brisk walk after lunch or during a phone call.",
                "Breathe deeply into your lower abdomen during the walk."
            ),
            reflectionPrompt = "How did brief physical movement shift your cognitive energy when you felt stuck?",
            estimatedMinutes = 15
        ),
        DayLesson(
            dayNumber = 12,
            weekNumber = 2,
            weekTitle = "Build Better Foundations",
            title = "Caffeine Awareness",
            whyItMatters = "Caffeine has a half-life of 5–7 hours. Having coffee after 2 PM can prevent deep stage-3 slow-wave sleep even if you fall asleep easily.",
            actionSteps = listOf(
                "Note the exact time you had your last caffeinated cup today.",
                "Aim to set your personal caffeine cutoff time at least 8 hours before bed.",
                "Switch to herbal tea, warm water, or sparkling water for late afternoon."
            ),
            reflectionPrompt = "At what hour was your final caffeine sip today, and how did your evening calmness feel?",
            estimatedMinutes = 5
        ),
        DayLesson(
            dayNumber = 13,
            weekNumber = 2,
            weekTitle = "Build Better Foundations",
            title = "Evening Wind-Down",
            whyItMatters = "A deliberate wind-down routine prepares your parasympathetic nervous system for restorative overnight recovery.",
            actionSteps = listOf(
                "Dim the overhead lights in your living space 60 minutes before bed.",
                "Prepare tomorrow's top 2 priorities so your mind doesn't rehearse them in bed.",
                "Play the 10-Minute Wind-Down audio session in the Reset tab."
            ),
            reflectionPrompt = "What made it easier to slow down and unwind tonight?",
            estimatedMinutes = 12
        ),
        DayLesson(
            dayNumber = 14,
            weekNumber = 2,
            weekTitle = "Build Better Foundations",
            title = "Weekly Review: Week 2",
            whyItMatters = "Two full weeks completed. Notice how small foundation adjustments compound into greater daily stamina.",
            actionSteps = listOf(
                "Review your 14-day completion streak.",
                "Compare your Week 1 vs Week 2 energy and mental clarity averages.",
                "Write down one foundation habit that has already become second nature."
            ),
            reflectionPrompt = "Which foundation habit (sleep, water, movement, or wind-down) yielded the highest reward?",
            estimatedMinutes = 10
        ),

        // WEEK 3: FOCUS & MEMORY
        DayLesson(
            dayNumber = 15,
            weekNumber = 3,
            weekTitle = "Focus & Memory",
            title = "Active Recall Practice",
            whyItMatters = "Memory is strengthened not by passive review, but by the mental effort of pulling information out of storage.",
            actionSteps = listOf(
                "Read a brief article, book page, or list of instructions.",
                "Close the page and summarize the main 3 points aloud or on paper from memory.",
                "Check back only after you have attempted full recall."
            ),
            reflectionPrompt = "What did you practice recalling today, and how easily did the details return?",
            estimatedMinutes = 8
        ),
        DayLesson(
            dayNumber = 16,
            weekNumber = 3,
            weekTitle = "Focus & Memory",
            title = "One Focus Block",
            whyItMatters = "Deep focus requires entering a flow channel. Structuring a protected 25-minute block shields executive function from constant interruption.",
            actionSteps = listOf(
                "Schedule a 25-minute appointment with yourself on your calendar.",
                "Play the 5-Minute Focus Preparation audio in the Reset tab.",
                "Work on your chosen high-value task without switching windows once."
            ),
            reflectionPrompt = "What was the outcome of your protected 25-minute focus block today?",
            estimatedMinutes = 25
        ),
        DayLesson(
            dayNumber = 17,
            weekNumber = 3,
            weekTitle = "Focus & Memory",
            title = "Distraction Audit",
            whyItMatters = "Most distractions are internal triggers (boredom, slight discomfort, or uncertainty) seeking quick novelty relief.",
            actionSteps = listOf(
                "Keep an index card next to your keyboard today.",
                "Every time you feel the impulse to check messages or open a browser tab, make a tick mark.",
                "Take one slow breath before deciding whether to follow the urge."
            ),
            reflectionPrompt = "What internal emotion (fatigue, uncertainty, or habit) triggered most distraction urges?",
            estimatedMinutes = 6
        ),
        DayLesson(
            dayNumber = 18,
            weekNumber = 3,
            weekTitle = "Focus & Memory",
            title = "Memory Cue Anchor",
            whyItMatters = "Associating new habits with existing visual or spatial cues offloads cognitive load from short-term memory.",
            actionSteps = listOf(
                "Place a physical cue where you cannot miss it (e.g. water bottle next to keyboard, book on nightstand).",
                "Repeat the mental statement: 'When I see [Cue], I will do [Action]'.",
                "Observe how effortlessly the cue initiates the routine."
            ),
            reflectionPrompt = "What physical cue did you establish today?",
            estimatedMinutes = 5
        ),
        DayLesson(
            dayNumber = 19,
            weekNumber = 3,
            weekTitle = "Focus & Memory",
            title = "Recall Without Looking",
            whyItMatters = "Daily reliance on digital lookups weakens retrieval pathways. Practicing conscious everyday retrieval keeps memory agile.",
            actionSteps = listOf(
                "Before checking your grocery list or calendar, mentally review every item first.",
                "Recall the name of someone you recently met or a phone number before checking contacts.",
                "Give your brain 30 seconds of curious effort before searching."
            ),
            reflectionPrompt = "What piece of everyday information did you challenge yourself to retrieve unassisted?",
            estimatedMinutes = 5
        ),
        DayLesson(
            dayNumber = 20,
            weekNumber = 3,
            weekTitle = "Focus & Memory",
            title = "Focus Reset Tool",
            whyItMatters = "When attention fractures mid-afternoon, attempting to push through leads to frustration. A structured 5-minute pause resets executive bandwidth.",
            actionSteps = listOf(
                "Open the Reset tab in the app.",
                "Follow the guided 7-step 5-Minute Mental Reset with the breathing circle.",
                "Return to your task with fresh, uncluttered eyes."
            ),
            reflectionPrompt = "How did the 5-minute reset shift your mental state before returning to your work?",
            estimatedMinutes = 7
        ),
        DayLesson(
            dayNumber = 21,
            weekNumber = 3,
            weekTitle = "Focus & Memory",
            title = "Weekly Review: Week 3",
            whyItMatters = "Three weeks of daily actions build genuine habit momentum. Reflecting on memory and focus habits clarifies personal best practices.",
            actionSteps = listOf(
                "Observe your 21-day progress milestone.",
                "Check your Focus and Mental Clarity trends over the past 7 days.",
                "Identify your single favorite focus ritual from this week."
            ),
            reflectionPrompt = "What focus or memory practice felt most natural and rewarding for you?",
            estimatedMinutes = 10
        ),

        // WEEK 4: MAKE IT STICK
        DayLesson(
            dayNumber = 22,
            weekNumber = 4,
            weekTitle = "Make It Stick",
            title = "Identify What Helped",
            whyItMatters = "Wellness advice is only useful if it fits your real life. Cataloging what genuinely made you feel clearer lets you discard what didn't.",
            actionSteps = listOf(
                "Review the past 3 weeks of reflections in your Track history.",
                "List the top 3 actions that produced noticeable positive differences in your day.",
                "Acknowledge how simple sustainable actions are compared to drastic overhauls."
            ),
            reflectionPrompt = "Which 3 specific practices gave you the clearest cognitive return on investment?",
            estimatedMinutes = 10
        ),
        DayLesson(
            dayNumber = 23,
            weekNumber = 4,
            weekTitle = "Make It Stick",
            title = "Remove What Didn't",
            whyItMatters = "Friction kills long-term routines. Removing practices that felt awkward or burdensome protects consistency for the habits that truly matter.",
            actionSteps = listOf(
                "Identify any exercise or habit from this month that felt like a chore.",
                "Give yourself full permission to let it go without guilt.",
                "Double down on the 2 or 3 practices that felt enjoyable and natural."
            ),
            reflectionPrompt = "What practice are you happily pruning so your core routine remains light and manageable?",
            estimatedMinutes = 7
        ),
        DayLesson(
            dayNumber = 24,
            weekNumber = 4,
            weekTitle = "Make It Stick",
            title = "Choose Your 3 Anchor Habits",
            whyItMatters = "Consistency thrives on simplicity. Three reliable anchors are far more powerful than twenty sporadic rules.",
            actionSteps = listOf(
                "Select one Morning Anchor (e.g. daylight + water).",
                "Select one Midday Anchor (e.g. 20-min single-task block + movement).",
                "Select one Evening Anchor (e.g. screen cutoff + wind-down).",
                "Write these 3 anchors on an index card or your fridge."
            ),
            reflectionPrompt = "What are your 3 chosen anchor habits for long-term mental sharpness?",
            estimatedMinutes = 10
        ),
        DayLesson(
            dayNumber = 25,
            weekNumber = 4,
            weekTitle = "Make It Stick",
            title = "Design Your Personal Routine",
            whyItMatters = "A personal routine honors your peak biological rhythm rather than imposing a generic rigid schedule.",
            actionSteps = listOf(
                "Map your anchor habits to your personal daily timeline.",
                "Assign realistic time windows (e.g. 7:30 AM light, 10:00 AM focus block, 9:30 PM wind-down).",
                "Ensure each step takes no longer than 5 to 15 minutes."
            ),
            reflectionPrompt = "How does your personalized routine feel when you visualize walking through tomorrow?",
            estimatedMinutes = 12
        ),
        DayLesson(
            dayNumber = 26,
            weekNumber = 4,
            weekTitle = "Make It Stick",
            title = "Build Your Minimum Version",
            whyItMatters = "On busy, exhausted, or traveling days, a 60-minute routine will break. A 2-minute minimum version guarantees your streak never stops.",
            actionSteps = listOf(
                "Define your 'Low-Energy Minimum Version' for each anchor (e.g. 1 glass of water, 3 deep breaths, 1 min reading).",
                "Confirm that your minimum version takes less than 3 minutes total.",
                "Remember: keeping the chain alive is about identity, not volume."
            ),
            reflectionPrompt = "What is your 2-minute minimum version when life gets hectic?",
            estimatedMinutes = 8
        ),
        DayLesson(
            dayNumber = 27,
            weekNumber = 4,
            weekTitle = "Make It Stick",
            title = "Plan for Difficult Days",
            whyItMatters = "Relapse is not failure; it is simply part of human nature. Having an 'If-Then' plan before a stressful day prevents total habit abandonment.",
            actionSteps = listOf(
                "Formulate an If-Then rule: 'If I feel completely overwhelmed, Then I will do a 2-minute reset audio.'",
                "Formulate another rule: 'If I miss a morning walk, Then I will take 5 minutes of fresh air at lunch.'",
                "Release any expectations of rigid perfection."
            ),
            reflectionPrompt = "What is your primary 'If-Then' compass when unexpected stress arrives?",
            estimatedMinutes = 8
        ),
        DayLesson(
            dayNumber = 28,
            weekNumber = 4,
            weekTitle = "Make It Stick",
            title = "Your Next 30 Days",
            whyItMatters = "The completion of a program is the threshold of enduring lifestyle transformation. Looking forward anchors your new identity.",
            actionSteps = listOf(
                "Reflect on how your confidence in your daily focus has evolved over 28 days.",
                "Decide whether you will cycle through the 30-day program again or sustain your 3 anchors.",
                "Ensure your daily reminder is set to your preferred morning time."
            ),
            reflectionPrompt = "In what subtle ways has your day-to-day focus and patience shifted since Day 1?",
            estimatedMinutes = 10
        ),

        // FINAL DAYS
        DayLesson(
            dayNumber = 29,
            weekNumber = 4,
            weekTitle = "Final Days",
            title = "Review Your Journey",
            whyItMatters = "Take this penultimate day to marvel at your discipline and the personal wisdom you have recorded.",
            actionSteps = listOf(
                "Browse through your past check-in notes and brain fog logs.",
                "Read your earliest reflections from Week 1 to observe the tangible shift in perspective.",
                "Prepare for your graduation milestone on Day 30."
            ),
            reflectionPrompt = "What surprised you most about your mind's resilience and adaptability this month?",
            estimatedMinutes = 10
        ),
        DayLesson(
            dayNumber = 30,
            weekNumber = 4,
            weekTitle = "Final Days",
            title = "Your Personal Mental Sharpness Plan",
            whyItMatters = "You made it to Day 30! The goal was never perfection; it was discovering which daily habits genuinely support your clarity and vitality after 40.",
            actionSteps = listOf(
                "Confirm and save your 3–5 permanent anchor habits in the Profile tab.",
                "Review the Post-30-Day Keep Going resources in the app.",
                "Celebrate your milestone: You have built the foundation of long-term cognitive wellness."
            ),
            reflectionPrompt = "What is the single most important principle you are carrying forward into your everyday life?",
            estimatedMinutes = 15
        )
    )
}
