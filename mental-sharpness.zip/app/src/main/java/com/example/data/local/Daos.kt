package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.BrainFogEntry
import com.example.data.model.DailyCheckIn
import com.example.data.model.DayCompletion
import com.example.data.model.UserNote
import kotlinx.coroutines.flow.Flow

@Dao
interface DayCompletionDao {
    @Query("SELECT * FROM day_completions ORDER BY dayNumber ASC")
    fun getAllCompletions(): Flow<List<DayCompletion>>

    @Query("SELECT * FROM day_completions WHERE dayNumber = :dayNumber LIMIT 1")
    suspend fun getCompletionForDay(dayNumber: Int): DayCompletion?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCompletion(completion: DayCompletion)

    @Query("DELETE FROM day_completions WHERE dayNumber = :dayNumber")
    suspend fun deleteCompletion(dayNumber: Int)

    @Query("DELETE FROM day_completions")
    suspend fun clearAll()
}

@Dao
interface DailyCheckInDao {
    @Query("SELECT * FROM daily_checkins ORDER BY timestamp DESC")
    fun getAllCheckIns(): Flow<List<DailyCheckIn>>

    @Query("SELECT * FROM daily_checkins WHERE dateString = :dateString LIMIT 1")
    suspend fun getCheckInForDate(dateString: String): DailyCheckIn?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCheckIn(checkIn: DailyCheckIn)

    @Query("DELETE FROM daily_checkins")
    suspend fun clearAll()
}

@Dao
interface BrainFogDao {
    @Query("SELECT * FROM brain_fog_entries ORDER BY timestamp DESC")
    fun getAllEntries(): Flow<List<BrainFogEntry>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEntry(entry: BrainFogEntry)

    @Delete
    suspend fun deleteEntry(entry: BrainFogEntry)

    @Query("DELETE FROM brain_fog_entries WHERE id = :id")
    suspend fun deleteEntryById(id: Long)

    @Query("DELETE FROM brain_fog_entries")
    suspend fun clearAll()
}

@Dao
interface UserNoteDao {
    @Query("SELECT * FROM user_notes ORDER BY timestamp DESC")
    fun getAllNotes(): Flow<List<UserNote>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: UserNote)

    @Delete
    suspend fun deleteNote(note: UserNote)

    @Query("DELETE FROM user_notes WHERE id = :id")
    suspend fun deleteNoteById(id: Long)

    @Query("DELETE FROM user_notes")
    suspend fun clearAll()
}
